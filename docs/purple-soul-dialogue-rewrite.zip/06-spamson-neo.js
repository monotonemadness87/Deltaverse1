// Spamson NEO — A Deal in the Dark
// Drop-in dialogue rewrite for Purple Soul. Generated against the 9 Oct 2026 archive.
// Each block between "// @@ <id>" and "// @@ end" replaces the archive block of the same id.
// Only quoted text changed: code, indices, face/pose numbers, speaker tags, destinations,
// bank lengths, template expressions and control/label strings are byte-for-byte the originals.

// @@ spamson-neo-D002 — INTRO
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 336.
INTRO=[
 ['n','* Hotland is empty. The barricades leave one road open.'],
 ['s','THERE YOU ARE, KID. RIGHT ON CUE.'],
 ['s','THE SENSATION OF YOUR SCREEN, THE SHOW THAT MAKES YOU SCREAM.'],
 ['s','THAT WAS HIS INTRO. EVERY NIGHT. RIGHT THROUGH MY WALL.'],
 ['s','SAY IT.'],
 ['n','* He waits for a name.'],
 ['s','MR. ANT TENNA. OUR HOST. MY PARTNER. THE FEATURE PRESENTATION.'],
 ['s','YOU TOOK HIM. NOW NOBODY TELLS ME WHEN I’M ON.'],
 ['s','TWO NAMES ON THE MARQUEE. SAME SIZE LETTERS. HE INSISTED.'],
 ['s','A LADY OFFERED ME A CONTRACT. YOUR CAPTURE. HIS REVENGE. I SIGNED WITHOUT READING IT.'],
 ['s','SHE KNEW YOUR ROAD. YOUR FACE. EVEN THE COLOR OF YOUR SOUL.'],
 ['s','I BORROWED AN ARM AND SOME WINGS FROM THE SCIENTIST. NO DEPOSIT REQUIRED.'],
 ['s','HE’D TELL ME TO READ THE SMALL PRINT. HE ALWAYS DID THE READING.'],
 ['n','* Purple strings hold your movement. UP / DOWN changes strings. Shoot RIGHT with Z.'],
 ['n','* Gold outlines can be shot. Tap for three-shot bursts; hold and release for a charge.'],
 ['s','TONIGHT’S FEATURE PRESENTATION: THE HUMAN WHO NEVER LEAVES.']
]
// @@ end

// @@ spamson-neo-D003 — REVIVAL
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 354.
REVIVAL=[
 ['s','TENNA? ...NO. NO. DON’T CALL THE CURTAIN YET.'],
 ['s','ONE LITTLE FREE SAMPLE. SOMEBODY LEFT IT ON A SHELF.'],
 ['s','ONE MORE CHANCE TO FINISH HIS SHOW. THAT’S ALL. THAT’S ALL I ASKED FOR.'],
 ['s','THE SENSATION OF YOUR SCREEN. THE SHOW THAT MAKES YOU SCREAM.'],
 ['s','SAY IT. SAY HIS NAME WHILE THERE’S STILL SOMEBODY HERE TO HEAR IT.'],
 ['s','BEHOLD, THE POWER OF NEO!'],
 ['n','* His body holds together. The wings ignite. He is still Spamson.'],
 ['n','* The strings turn vertical. LEFT / RIGHT changes strings; UP / DOWN travels along them.'],
 ['n','* You shoot UP. Generators take FIVE shots or ONE charged shot. Break one to expose Spamson for your next FIGHT.'],
 ['n','* You can leave generators intact. Their lasers spare the green-marked string.']
]
// @@ end

// @@ spamson-neo-D004 — INTERCEPT
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 366.
INTERCEPT=[
 ['s','TENNA. I... I MISSED MY CUE.'],
 ['m','Ahuhuhu~ Such a devoted little performer.'],
 ['s','YOU! THE CONTRACT! I CAN STILL FINISH IT!'],
 ['m','Oh, dearie. You already gave me everything I wanted.'],
 ['s','THAT’S MY GOOD ARM. WAIT. THE CANNON ISN’T—'],
 ['m','I watched every step. Every shot. Every delicious little mistake.'],
 ['s','YOU SAID WE HAD A DEAL! A SIGNED DEAL!'],
 ['m','You promised me dinner, dearie. You never asked what was on the menu~'],
 ['s','TENNA... I’M SORRY. I COULDN’T HOLD THE SHOW.']
]
// @@ end

// @@ spamson-neo-D005 — ENDING
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 377.
ENDING=[
 ['m','Ahuhuhu~ One little delivery, signed for.'],
 ['m','And the main course is walking to my table all by itself~'],
 ['n','* The silk drags him past the barricade. His arm is still intact.'],
 ['n','* You never land the finishing blow.'],
 ['n','* Somewhere deeper in the dark, something laughs back.'],
 ['n','* The only open road leads into the nest.']
]
// @@ end

// @@ spamson-neo-D006 — BARKS
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 385.
BARKS={
1:['SAY HIS NAME.','THE SHOW THAT MAKES YOU SCREAM.','HE WAS THE FEATURE PRESENTATION.','OUR NAMES. SAME SIZE LETTERS.','NO. HIS SPOTLIGHT STAYS ON.'],
2:['THE SENSATION OF YOUR SCREEN!','YOU WILL REMEMBER MR. ANT TENNA.','HE’D HAVE CALLED THIS THE ENCORE.','LOOK, TENNA. I KEPT THE CAMERA ROLLING.','OUR FEATURE PRESENTATION ISN’T OVER.','HE PROMISED WE’D BOTH BE BIG SHOTS.','I CAN STILL HEAR YOUR CUE, PARTNER.','SAY IT. SAY IT LOUD ENOUGH FOR HIM.'],
3:['TONIGHT’S FEATURE PRESENTATION!','THE SHOW GOES ON, TENNA!','LOOK AT ME, PARTNER!','THE SHOW THAT MAKES YOU—']}
// @@ end

// @@ spamson-neo-D007 — TURN_LINES
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 389.
TURN_LINES={
1:[
 [['s','I USED TO BANG ON THE WALL WHEN HE PRACTICED THAT INTRO.'],['s','NOW I’D PAY FULL PRICE TO HEAR IT AGAIN.']],
 [['s','THE SENSATION OF YOUR SCREEN. THE SHOW THAT MAKES YOU SCREAM.'],['s','YOU KNOW THE WORDS, KID. DON’T PRETEND YOU DON’T.']],
 [['s','HE WANTED THE MARQUEE. I WANTED THE SALES.'],['s','THEN HE PUT MY NAME NEXT TO HIS. JUST LIKE THAT. NO COMMISSION.']],
 [['s','THE CONTRACT LADY SAID SHE COULD HELP ME FIND YOU.'],['s','I DIDN’T HAVE ANYBODY ELSE LEFT TO ASK.']]
],
2:[
 [['s','I CAN FEEL EVERYTHING THAT SHOULD HAVE BROKEN.'],['s','HE ALWAYS SAID THE SHOW HAS TO HOLD TOGETHER. WELL? IT’S HOLDING.']],
 [['s','SAY IT.'],['s','MR. ANT TENNA. NOT “THAT LITTLE GUY.” NOT “THE OTHER ONE.”']],
 [['s','HE ONCE ANNOUNCED ME TO THREE PEOPLE AND A BROKEN MAILBOX.'],['s','MADE IT SOUND LIKE THE WHOLE UNDERGROUND SHOWED UP.']],
 [['s','THE WINGS PULL. THE ARM FIRES. NOBODY’S HERE TO BRACE ME.'],['s','HE WOULD HAVE BEEN. EVEN IF I TOLD HIM TO RUN.']],
 [['s','BREAK THE GENERATORS. CUT THE WIRES. GO AHEAD.'],['s','HIS NAME IS STILL ON THE SIGN. YOU DON’T GET TO TAKE THAT TOO.']],
 [['s','I DIDN’T ASK WHAT WAS IN THE SAMPLE.'],['s','I ASKED IF IT COULD GET ME THROUGH ONE MORE FEATURE PRESENTATION.']],
 [['s','SHE LAUGHED WHEN I SAID THIS WAS FOR TENNA.'],['s','I THOUGHT SHE UNDERSTOOD. EVERYBODY LIKED HIM. EVERYBODY.']],
 [['s','THE SENSATION OF YOUR SCREEN. THE SHOW THAT MAKES YOU SCREAM.'],['s','THERE. THAT’S YOUR CUE, PARTNER. ...PARTNER?']],
 [['s','HE PROMISED WE’D BE THE TWO HEROES WHO CAUGHT THE HUMAN.'],['s','I’LL TAKE HALF THE BILLING. JUST LET ME FINISH HIS HALF.']],
 [['s','I ALWAYS HAD SOMETHING TO SELL. HE ALWAYS HAD SOMETHING TO SAY.'],['s','SO I’M SAYING IT. UNTIL YOU REMEMBER.']]
]}
// @@ end

// @@ spamson-neo-D008 — reset
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 110.
reset(checkpoint=false){
  this.paused=false;this.clock=0;this.timer=0;this.turn=0;this.phaseTurn=0;this.hp=this.maxHP=48;this.lv=8;this.items=copy(ITEMS);this.phase=checkpoint?this.checkpoint:1;this.enemyMax=this.phase===1?36:60;this.enemyHP=this.phase===3?12:this.enemyMax;this.injections=this.phase===1?0:1;this.injected=this.phase>1;this.melted=false;this.hitCount=0;this.blindFinish=false;this.captureStarted=false;this.won=false;this.bullets=[];this.shots=[];this.effects=[];this.selected=0;this.option=0;this.actName='';this.charge=0;this.fireHeld=false;this.burst=0;this.shotCD=0;this.burstCD=0;this.invuln=0;this.laneCD=0;this.exposed=false;this.read=false;this.bait=false;this.cutWires=false;this.totalRelays=0;this.totalDamage=0;this.attackCount=0;this.attackAge=0;this.face=6;this.bark='';this.barkAge=0;this.boss={x:384,y:243,angle:Math.PI/2};this.lastInput={};this.setupArena(this.phase>1?'vertical':'horizontal');this.emit('reset');
  if(this.phase===3){this.startFinal();this.emit('neoStart');}else if(this.phase===2){this.dialogue([['s','THE SECOND ACT IS STILL MINE.'],REVIVAL.at(-1)],'menu');this.emit('neoStart');}else this.dialogue(INTRO,'menu');
 }
// @@ end

// @@ spamson-neo-D009 — confirm
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 123.
confirm(){
  if(this.paused)return;
  if(this.state==='title'){this.reset();return;}
  if(this.state==='dialogue'){if(this.displayChars<this.current.text.length){this.displayChars=this.current.text.length;return;}if(++this.page<this.pages.length){this.displayChars=0;return;}this.state=this.afterDialogue;this.timer=0;if(this.state==='menu')this.menu();else if(this.state==='captured'){this.captureAge=0;this.emit('web');}return;}
  if(this.state==='menu'){const action=this.options()[this.selected];if(action==='FIGHT'){this.state='timing';this.timer=0;this.emit('select');}else{this.state=action.toLowerCase();this.option=0;}return;}
  if(this.state==='timing'){this.strike();return;}
  if(this.state==='act'){this.act(this.option);return;}
  if(this.state==='item'){this.useItem(this.option);return;}
  if(this.state==='mercy'){this.dialogue([['s',this.option?'THAT ROAD GOES THROUGH ME, KID.':'TENNA DOESN’T GET TO COME BACK. WHY SHOULD YOU?']],'attackReady');return;}
  if(this.state==='finishPrompt'){this.state='finishAttempt';this.timer=0;this.emit('revealMusic');return;}
 }
// @@ end

// @@ spamson-neo-D010 — strike
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 134.
strike(){const precision=Math.max(0,1-Math.abs(this.timer%1.6-.8)/.8),raw=Math.round(6+12*precision);let damage=this.phase===1?raw:Math.max(1,Math.round(raw*(this.exposed?1:.22)));this.exposed=false;this.damageBoss(damage);this.emit('gentleStrike');this.effects.push({type:'damage',x:this.boss.x,y:145,text:String(damage),life:1.2});if(this.state==='timing'){this.say(this.phase===1?'THAT’S ALL YOU BROUGHT?':'STILL. STANDING.',8);this.beginAttack();}}
// @@ end

// @@ spamson-neo-D011 — act
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 139.
act(i){
  this.actName=this.options()[i];let text;
  if(i===0)text=this.phase===1?'* SPAMSON — 36 HP. Stolen hardware. A personal grudge.':'* SPAMSON NEO — 60 HP. The sample holds him together. Broken gold relays expose him for your next FIGHT.';
  if(i===1){this.read=true;text='* You watch the barrel and wing signals. The next attack warns longer.';}
  if(i===2){this.bait=true;text='* You challenge him to aim the cannon himself. He commits to wider, slower sweeps.';}
  if(i===3){this.cutWires=true;text='* You cut a dangling control lead. Wing crossfire shuts down for the next attack.';}
  this.dialogue([['n',text],['s',['STILL COUNTING, KID?','THEN WATCH CLOSELY.','I DON’T NEED A CO-HOST TO AIM!','HEY! THAT WAS A RENTAL!'][i]]],'attackReady');
 }
// @@ end

// @@ spamson-neo-D012 — useItem
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 147.
useItem(i){const item=this.items[i];if(!item?.count){this.dialogue([['n','* There is none left.']],'menu');return;}item.count--;this.hp=Math.min(this.maxHP,this.hp+item.heal);this.emit('heal');this.dialogue([['n','* You eat '+item.name+'. '+item.heal+' HP restored.'],['s','I PACKED SOMETHING TOO. FOR LATER.']],'attackReady');}
// @@ end

// @@ spamson-neo-D014 — startFinal
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 149.
startFinal(){this.phase=3;this.state='overdrive';this.timer=0;this.checkpoint=3;this.bullets=[];this.shots=[];this.menuPieces=Array.from({length:4},(_,i)=>({x:48+i*184,y:541,vx:(i-1.5)*190,vy:-150-i*15}));this.say('THE FEATURE PRESENTATION. FOR YOU, TENNA.',9);this.emit('menuBlast');this.setupArena('vertical',true);this.finalAge=0;this.nextCast=1.6;this.castIndex=0;this.pattern='last';this.duration=52;this.fireHeld=false;this.charge=0;this.burst=0;this.shotCD=0;this.burstCD=0;}
// @@ end

// @@ spamson-neo-D015 — this.say
// Type: event. Source: ` engine.js `; owner ` cast `; script line 169.
// Trigger:  if p==='wings'&&this.cutWires 
this.say('THOSE WIRES WERE LOAD-BEARING!',1)
// @@ end

// @@ spamson-neo-D016 — this.say
// Type: event. Source: ` engine.js `; owner ` hazards `; script line 183.
// Trigger:  if Math.hypot(shot.x-b.x,shot.y-b.y)<shot.r+b.r  →  if b.hp<=0  →  if b.kind==='relay' 
this.say('HE BUILT THAT FOR OUR FEATURE PRESENTATION!',1)
// @@ end

// @@ spamson-neo-D018 — this.say
// Type: event. Source: ` engine.js `; owner ` update `; script line 193.
// Trigger:  if this.state==='collapse'  →  if this.timer>1.6 
this.say('NO. NO. HIS SHOW ISN’T OVER.',9)
// @@ end

// @@ spamson-neo-D022 — this.say
// Type: event. Source: ` engine.js `; owner ` update `; script line 203.
// Trigger:  if this.state==='final'&&Math.floor(this.finalAge/13)!==Math.floor((this.finalAge-dt)/13)&&this.finalAge<51 
this.say(this.orientation==='vertical'?'UP, KID! KEEP LOOKING UP!':'THEN TAKE THE SCENIC ROUTE!',8)
// @@ end

// @@ supplementary — reactive lines from the archive's "Additional text" ledger
// These live outside the banks above. Find `old` at `where` and replace it with `new`.
const SUPPLEMENTARY_LINE_REWRITES=[
 {id:'spamson-neo-T088',where:'entry / inline / render · text(\'He cannot stand.\',384,309,2,\'#ddd\',true)',
  old:'He cannot stand.',
  new:'He can’t stand up.'},
];
// @@ end
