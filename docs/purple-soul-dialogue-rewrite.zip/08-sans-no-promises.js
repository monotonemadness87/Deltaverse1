// Sans — No Promises
// Drop-in dialogue rewrite for Purple Soul. Generated against the 9 Oct 2026 archive.
// Each block between "// @@ <id>" and "// @@ end" replaces the archive block of the same id.
// Only quoted text changed: code, indices, face/pose numbers, speaker tags, destinations,
// bank lengths, template expressions and control/label strings are byte-for-byte the originals.

// @@ sans-D002 — OPENING
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 382.
OPENING=[
 ['heya. nice view, huh?',0],
 ['you made it through waterfall in one piece. heard you even stayed for the show.',1],
 ['normally this is where i’d ask you a few questions. maybe give a little speech.',0],
 ['today, though? we’re kinda short on options.',3],
 ['asgore’s a good guy. you know that?',4],
 ['i’d hate to make him bury another kid.',3],
 ['me, though? eh. i sleep fine. i can sleep through pretty much anything.',2]
]
// @@ end

// @@ sans-D003 — BETWEEN
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 391.
BETWEEN=[
 [['huh. still standing. don’t take this personally, kid. i’m technically on the clock.',1]],
 [['alphys is the royal scientist. i’m her assistant. sometimes she lets me touch the expensive stuff.',0],['the guy before her was a tough act to follow. she’s brilliant anyway. don’t tell her i said that.',4]],
 [['we work well together. late nights. takeout. takeout going cold ’cause we’re still working.',1],['...anyway. it’s complicated. you’re a little young for the break room gossip.',2]],
 [['asgore asked me to take the big job once. he wasn’t the only one who asked, either.',0],['told ’em i’m not great with responsibility. or mornings. turns out the job came with both.',1],['and you take a job like that, every problem down here gets your name on it.',3]],
 [['for a while, she had me convinced we could open the barrier without anybody else getting hurt.',4],['so i helped. figured i could help without my name going on the door.',0],['...turns out the door wasn’t the problem.',3]],
 [['a few of the patients woke back up.',3],['that was supposed to be the good part.',3],['...she’s still trying to fix it. let’s just leave it at that.',2]],
 [['there’s another human down here. busy little thing. leaves a lot of empty rooms behind.',3],['that one? asgore can have ’em, no questions asked. might even help him sleep at night.',1],['what i can’t have is you two teaming up. so this is where your trip ends, pal.',3]],
 [['funny thing, huh? nobody asks to get mixed up in this stuff.',4],['you just pick one road instead of another, and suddenly it’s your fault you got involved.',3],['guess we’ve got that in common.',4],['...anyway. watch your step.',0]]
]
// @@ end

// @@ sans-D004 — CALL
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 401.
CALL=[
 ['...hang on. work’s calling.',6],
 ['S-SANS!? What are you DOING!? I’m looking at the CORE readings right now! Please tell me that isn’t—',0,'alphys'],
 ['hey, doc.',6],
 ['Th-they’re a KID, Sans! Stop! I’m coming down there!',0,'alphys'],
 ['...',6],
 ['welp. guess i gotta wrap this up.',3],
 ['pay attention, kid. you don’t wanna miss the part where i actually try.',1]
]
// @@ end

// @@ sans-D005 — ENDING
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 410.
ENDING=[
 ['heh. heheheh...',5],
 ['you really don’t quit, huh?',4],
 ['i wonder...',3],
 ['nah. forget it.',2],
 ['all right, kid. go ahead. i care a little. just not that much.',0],
 ['but here’s some free advice.',1],
 ['turn around. find somewhere quiet to hide.',3],
 ['keep going forward and... heh. well. i’d say you’ll regret it.',4],
 ['but you probably won’t live long enough to.',12]
]
// @@ end

// @@ sans-D006 — confirm
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 133.
confirm(){
  if(this.state==='dead'&&(this.deathAge||0)<1.8)return;
  if(this.paused||['won','dead','exit','attack','cheat'].includes(this.state))return;
  if(this.state==='ready'){this.emit('music');this.message(OPENING);return;}
  if(this.state==='dialogue'){if(this.display<this.text.length){this.display=this.text.length;this.emit('voice-stop');return;}if(this.pages.length){this.nextPage();return;}this.emit('voice-stop');if(this.next==='attack')this.startAttack();else if(this.next==='final'){this.finalStarted=true;this.startAttack();}else if(this.next==='exit')this.startExit();else this.menu();return;}
  if(this.state==='menu'){this.state=['fight','act','item','mercy'][this.selected];this.option=0;this.time=0;this.emit('select');return;}
  if(this.state==='fight'){this.interruptFight();return;}
  if(this.state==='item'){if(!this.items)return;this.items--;this.hp=Math.min(this.maxHP,this.hp+14);this.emit('heal');this.message([['instant noodles, huh? good. somebody around here should take a break.',1]],'attack');return;}
  if(this.state==='mercy'){this.message([[this.round<5?'you’re a nice kid. that’s kind of the problem.':'sure would be nice if that button fixed everything, huh?',4]],'attack');return;}
  if(this.state==='act'){const response=this.option===0?'sans. 1 atk 1 def. seems pretty comfortable with those numbers.':this.option===1?(this.round<4?'hey. don’t make me put “dating advice” on my timesheet.':'she’s doing her best. sometimes that’s the scary part.'):this.option===2?'sure, talk away. i can multitask. kinda.':'waiting me out? finally, someone who respects my work ethic.';this.message([[response,this.option===1?4:1]],'attack');}
 }
// @@ end

// @@ sans-D015 — this.message
// Type: event. Source: ` engine.js `; owner ` update `; script line 274.
// Trigger:  if this.state==='cheat'  →  if this.time>1.3 
this.message([[this.cheatType==='gravity'?'huh. must be something wrong with your aim.':'sorry, pal. that spot’s reserved.',1]],'attack')
// @@ end

