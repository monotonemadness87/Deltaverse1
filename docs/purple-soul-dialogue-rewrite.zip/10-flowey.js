// Flowey — Inside Your Best Friend
// Drop-in dialogue rewrite for Purple Soul. Generated against the 9 Oct 2026 archive.
// Each block between "// @@ <id>" and "// @@ end" replaces the archive block of the same id.
// Only quoted text changed: code, indices, face/pose numbers, speaker tags, destinations,
// bank lengths, template expressions and control/label strings are byte-for-byte the originals.

// @@ flowey-D001 — QUIZZES
// Type: dialogue/data bank. Source: ` nightmare-scenes.js `; owner ` modules["nightmare-scenes.js"] `; script line 270.
QUIZZES=[
 {question:'WHAT DID SHE WANT MOST?',answers:['A BIGGER STAGE','A BETTER BODY','SOMEONE TO WATCH'],ruined:['A BOX ON A SHELF','A BODY THAT WON’T WAKE','AN EMPTY SEAT'],reply:'Correct! Oh, wait. I changed the question. Hee hee hee.'},
 {question:'WHEN YOUR HEART STOPS, WHO WILL COME LOOKING?',answers:['NO ONE','SOMEONE TOO LATE','HE ALREADY HAS YOU'],reply:'Aww. You’re still waiting for a fourth answer. That’s ADORABLE.'},
 {question:'WHAT WILL THE KING REMEMBER ABOUT YOU?',answers:['YOUR COLOR','THE NUMBER ON THE JAR','HOW EASY IT WAS'],reply:'Don’t worry! I’ll remember every funny little face you made. Every single one.'},
 {question:'WHAT DID ALL THAT APPLAUSE BUY YOU?',answers:['ONE MORE TURN','A LONGER GOODBYE','NOTHING AT ALL'],reply:'Nothing! Golly, and you worked SO hard for it, too!'}
]
// @@ end

// @@ flowey-D004 — INTRO
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 643.
INTRO=[
 line('Howdy!\nMiss me?',0),line('Golly. All that walking... and look where it got you!',1),
 line('Inside your best friend.\nHee hee hee.',2),line('A purple SOUL. You just don’t know when to quit, do you?',1),
 line('That notebook. That silly little show. That lazy skeleton who just let you walk on by.',7),line('I was watching the whole time.\nYou never even noticed!',3),
 line('You were gonna die anyway, you know. I just got to you before the king did.',0),
 line('So let’s make this easy.\nQuit struggling.',1),line('...No?\nWell! Don’t say I didn’t ask nicely.',2)
]
// @@ end

// @@ flowey-D005 — AFTER
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 650.
AFTER=[
 [line('Aww. You dodged them.',8),line('And here I was trying to make you feel welcome!',0),line('You’re still looking for a way out, aren’t you?',1),line('Go ahead.\nI like watching you look.',2)],
 [line('Did you like that?\nI can do it again.',0),line('And again. And again. And AGAIN.',3),line('What? You thought YOU were the only one who could keep trying?',1),line('Don’t look so surprised. It’s rude.',7)],
 [line('You pressed it because it looked familiar.',1),line('Hee hee. That’s the best part!',3),line('Draw a little box around a word, and you’ll do whatever it says!',2),line('Go on. Tell me I’m wrong.',1)],
 [line('Those little arrows.\nYou trust them so much.',0),line('But look! I flip ONE thing, and suddenly you’re helpless.',1),line('It’s almost cute.',3),line('...Stop getting used to it.',4)],
 [line('Whew! That was close!',0),line('Almost had you that time.',2),line('Do you know how sick I am of “almost”?',7),line('Hold STILL for ONE SECOND!',4)],
 [line('What’s wrong?\nIt said MERCY.',8),line('Maybe you didn’t press it hard enough.',1),line('Maybe I changed my mind.',3),line('Maybe it was always going to hurt you.',2)],
 [line('They’re MY controls now.',4),line('You don’t get to pull the other way!',4),line('...Huh. You’re still doing it.',5),line('Fine. Let’s move something bigger.',1)],
 [line('There. Nice and tidy.\nNo name. No messy little memories.',0),line('You don’t need any of that anymore.',7),line('Just listen to me, and we’ll get along GREAT.',1),line('...You’re not listening.',4)],
 [line('See? There’s nothing past the screen.',1),line('There’s no door. No shortcut. No nice monster coming to save you.',2),line('It’s just you and me.',7),line('And I’ve got ALL the time in the world.',3)],
 [line('That’s better.\nFewer choices.',0),line('You should thank me. Thinking so hard must be exhausting.',1),line('What? Still not happy?',7),line('Gee, you’re hard to please.',4)],
 [line('You believed it!\nFor a second, you BELIEVED it!',3),line('You really thought you could just quit and walk away.',2),line('Sorry! No breaks.',0),line('Not until I’m done with you.',7)],
 [line('I split you up. I turned you around. I even killed you. Sort of.',4),line('And you’re STILL here.',5),line('Okay. You wanna be difficult?',1),line('Then I’ll quit being nice.',2)],
 [line('That box? I put it there.',1),line('I can put it somewhere else.',3),line('I can crush it. I can rip it in half.',2),line('I can take away the floor you’re standing on.',7),line('Try dodging THAT.',4)],
 [line('Two pieces.\nStill one pesky little idiot.',4),line('That’s your whole trick, isn’t it?',7),line('You fall apart, you put yourself back together, and you pretend it mattered.',1),line('Well! I know a few tricks too.',2)],
 [line('Hey, remember Encore?',0),line('All that fuss over a little letter.',1),line('He really thought opening it would fix something.',7),line('And you just stood there and LISTENED. Like it mattered!',3),line('...You’re angry.\nGOOD.',2)],
 [line('And the thing behind the door! What a show that was.',1),line('“The child is still asleep.”\nBlah, blah, blah.',3),line('You promised it something, didn’t you?',7),line('Bet you didn’t think a flower was listening.',1),line('I remember what you said.\nEvery word.',6)],
 [line('For a second, you weren’t sure if that was me.',1),line('Maybe something really broke. Maybe it was finally over.',3),line('Nope!\nStill here!',0),line('Just like you.',7)],
 [line('You know what happens if you get out, right?',7),line('The king takes your SOUL, puts it in a jar, and sticks it on a shelf.',1),line('All this effort... for THAT?',3),line('I’m offering you something better. You get to stay with me.',0),line('Forever.\nSo stop saying no.',4)],
 [line('...Fine.',7),line('There’s your way out.\nGo on.',1),line('I won’t stop you.\nHee hee. I couldn’t, right?',11),line('You’ll die out there.',7),line('But if that’s what you want...\nChoose.',10)]
]
// @@ end

// @@ flowey-D006 — AMBIENT
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 671.
AMBIENT=[
 ['Smile! Here they come!','Friendliness pellets!','Whoops! Almost got you!'],
 ['Hold that pose.','Let’s try that again.','I liked you better over THERE.'],
 ['Hey! You dropped something!','Go on. Press it!','Oops! Wrong button!'],
 ['Your left? Or MY left?','Try the other way!','Hee hee. Look at you!'],
 ['Open wide!','Aw, don’t be shy.','Stay away from the teeth! Or don’t.'],
 ['Here! I fixed MERCY for you!','It says HEAL. Must be good!','You really want to believe me, huh?'],
 ['Nope! This way!','I said THIS way!','Those hands aren’t yours anymore.'],
 ['Let’s get rid of that name.','You won’t miss it.','WHY DOES IT KEEP COMING BACK?'],
 ['Nice reflection!','Who’s in charge now?','You’re really getting on my nerves.'],
 ['Up? Sorry. Don’t have it.','Down still works. For now.','Less thinking. More running!'],
 ['Oh no! You lost!','What’ll you choose this time?','Hee hee. You never learn.'],
 ['Two of you? Lucky me!','Which one should I hit?','How about BOTH?'],
 ['Hold on! I’m redecorating!','No, no. The box goes over HERE.','Who said it needed four walls?'],
 ['Oops! Broke it!','Z. Go ahead. Jump across.','It won’t save you. Nothing will.'],
 ['Places, everyone!','You wanted another show, didn’t you?','Smile! Your friend’s watching!'],
 ['Shhh. You’ll wake the child.','The door’s right there! Take it!','What? Don’t you trust me?'],
 ['Oh dear. Something broke.','Better press something!','You’ll do anything to make it stop.'],
 ['New game! Same idiot!','Do you want to try again?','You don’t get to say no.'],
 ['I gave you a CHOICE!','YOU’RE SUPPOSED TO PICK ME!','DIE, THEN! SEE IF I CARE!']
]
// @@ end

// @@ flowey-D008 — MEMORY_LINES
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 701.
MEMORY_LINES=[
 [line('Hey! That’s mine now!',4),line('You don’t need a name in here.',7),line('...I SAID you don’t need it.',4)],
 [line('Ugh. That stupid little show again?',1),line('He would’ve hurt you if you let him.',2),line('So would I. At least I’m honest!',3)],
 [line('Promises?\nSeriously?',7),line('You don’t owe them anything.',1),line('You owe ME. I let you live this long.',2)],
 [line('Don’t get all soft on me.',4),line('That thing had a sword bigger than you!',1),line('You’re lucky you got out in one piece.',7)],
 [line('Why do you keep GETTING UP?',9),line('You’re not winning! You’re just taking longer to lose!',4),line('...Look at me when I’m talking to you.',7)],
 [line('Put it down.',7),line('You think you’re better than me? Is that it?',4),line('...Whatever. I don’t need you to like me.',10)]
]
// @@ end

// @@ flowey-D012 — confirm
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 133.
confirm(){if(this.paused||this.state==='dead'&&(this.deathAge||0)<1.8)return;if(this.quiz){this.answerQuiz(this.quiz.selected);return;}if(this.fakeDeath){this.pressFakeOver(this.fakeOverSelection);return;}
  if(this.state==='dialogue'){if(this.displayChars<this.text.length){this.displayChars=this.text.length;return;}if(this.pages.length){this.showPage();return;}if(this.next==='menu')this.toMenu();else if(this.next==='warning')this.startAttack();else if(this.next==='memory')this.startMemory(Math.floor(this.completed/2)-1);else if(this.next==='retryMemory')this.startMemory(this.memory);else if(this.next==='escaped'||this.next==='cut'){this.state=this.next;this.timer=0;this.emit('end');}return;}
  if(this.state==='menu'){
   const id=['fight','act','item','mercy'][this.selected];
   if(this.completed>=ATTACKS.length&&(id==='mercy'||id==='fight')){this.message(id==='fight'?RELEASE:CUT,id==='fight'?'escaped':'cut');return;}
   if(this.locked(id)){this.face=id==='mercy'?8:3;this.effects.push({type:'refused',text:id==='mercy'?'MERCY DISCONNECTED':`${id.toUpperCase()} NOT FOUND`,life:1.5});this.say(id==='mercy'?'Golly! You STILL think that does something?':id==='item'?'No snacks until I say so.':'Oops! Guess you’re not allowed to do that.',this.face,2.4);this.emit('deny');return;}
   if(id==='fight'){this.state='strike';this.cursor=74;this.cursorDir=1;this.timer=0;}else if(id==='act'){this.state='act';this.option=0;}else if(id==='item'){if(this.items.some(i=>i.count)){this.state='item';this.option=0;}else{this.effects.push({type:'refused',text:'NOTHING LEFT',life:1.3});this.emit('deny');}}return;
  }
  if(this.state==='strike'){const accuracy=clamp(1-Math.abs(this.cursor-384)/310,0,1);this.nerve=accuracy;const damage=Math.round(100+300*accuracy);this.enemyHP=Math.max(1,this.enemyHP-damage);this.effects.push({type:'damage',text:String(damage),life:1.3});this.face=accuracy>.65?4:1;this.emit('strike');this.message([line(accuracy>.65?'HEY! Watch it, you little brat!':'You missed! Wanna try again? Too bad, idiot!',this.face),line('Hee hee. My turn.',2)]);return;}
  if(this.state==='act'){const id=this.option;if(id===0){this.assist=true;this.message([line(MEMORIES.find((m,i)=>!this.fragments[i])?.thought||'You remember the last page of your notebook.',-1),line('Hey! Put that down!',4)]);}else if(id===1){this.resisted=true;this.message([line('You grip the notebook. Your hands stop shaking.',-1),line('Hee hee. We\'ll see.',1)]);}else if(id===2){this.assist=true;this.message([line('You call the names of the monsters you met.',-1),line('Nobody’s coming, idiot! It’s just you and ME!',4)]);}else this.message([line(`FLOWEY\nYour soul is inside him.\n${this.count} / 6 torn pages recovered.`, -1),line(this.count===6?'All six pages are yours. Keep going.':'Your torn pages are still glowing. Take them back.',-1)]);return;}
  if(this.state==='item'){const item=this.items.filter(i=>i.count)[this.option];if(!item)return;const heal=Math.min(this.maxHP-this.hp,item.heal);this.hp+=heal;item.count--;this.emit('heal');this.message([line(`You recover ${heal} HP.\nIt still feels like your heartbeat.`, -1),line('Hey! Quit helping yourself!',7)],this.completed>=ATTACKS.length?'menu':'warning');return;}
  if(['defend','memory'].includes(this.state)){if(this.split){this.switchPiece();return;}if(['yellow','hybrid'].includes(this.mode))this.shotRequested=true;if(this.memory>=0&&this.mode!=='yellow')this.callMemory();if(this.fakeDeath){this.fakeDeath=false;this.bullets=[];this.invulnerability=1;this.say('Hee hee. Gotcha!',3);}return;}
  if(this.state==='dead'){this.retry();return;}
 }
// @@ end

// @@ flowey-D023 — beginFakeOver
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 225.
beginFakeOver(duration=10){this.fakeDeath=true;this.fakeOverUntil=this.attackTime+duration;this.fakeOverClicks=0;this.fakeOverSelection=0;this.bullets=[];this.traps=[];this.face=0;this.say('Oh no! You lost! Well, golly. That’s that.',0,4);this.emit('dead');}
// @@ end

// @@ flowey-D024 — pressFakeOver
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 226.
pressFakeOver(index){if(!this.fakeDeath||this.paused)return;const name=['CONTINUE','RETRY','QUIT'][index];this.fakeOverClicks++;this.endFakeOver();this.addTrap(name,()=>({x:0,y:0,w:0,h:0}),name,null,2);this.pressTrap(this.traps.at(-1).id);this.say(['You wanted to keep playing? Then PLAY.','Same mistake. Again. And again. And AGAIN!','Quit? You think YOU get to decide that?'][index],index===2?2:3,4);}
// @@ end

// @@ flowey-D029 — g.say
// Type: event. Source: ` nightmare-scenes.js `; owner ` at callback `; script line 303.
// Trigger:  g.at(37) 
g.say('He let you through. All the way to ME. Thanks, pal!',3,5)
// @@ end

// @@ flowey-D038 — g.say
// Type: event. Source: ` patterns.js `; owner ` at callback `; script line 495.
// Trigger:  else of ['broadcast','smallprint','closing','spamneo'].includes(p)  →  else of p==='mettalot'  →  else of p==='sans'  →  else of p==='pellets'  →  else of p==='save'  →  else of p==='buttons'  →  else of p==='turn'  →  else of p==='mouth'  →  else of p==='mercy'  →  else of p==='hands'  →  else of p==='name'  →  else of p==='screen'  →  else of p==='delete'  →  else of p==='over'  →  else of p==='you'  →  else of p==='grab'  →  else of p==='split'  →  else of p==='encore'  →  else of p==='rift'  →  else of p==='tabs'  →  else of p==='restart'  →  if p==='last'  →  g.at(45) 
g.say('You can’t win! Even if you DO get out, you’re DEAD!',9,4)
// @@ end

