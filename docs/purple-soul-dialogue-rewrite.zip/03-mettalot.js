// Mettalot — Waterfall After Dark
// Drop-in dialogue rewrite for Purple Soul. Generated against the 9 Oct 2026 archive.
// Each block between "// @@ <id>" and "// @@ end" replaces the archive block of the same id.
// Only quoted text changed: code, indices, face/pose numbers, speaker tags, destinations,
// bank lengths, template expressions and control/label strings are byte-for-byte the originals.

// @@ mettalot-D002 — QUIZ
// Type: dialogue/data bank. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 65.
QUIZ=[
 {q:'Where’s the HOTTEST show in the Underground tonight?',a:['HOTLAND','RIGHT HERE','THE DUMP','MY FRIDGE'],right:1,reply:'Correct! Hotland has lava. WE have ambiance.'},
 {q:'Question! My future body absolutely MUST have…',a:['GREAT LEGS','EIGHT LEGS','NO LEGS','YOUR LEGS'],right:0,reply:'Oh, you get it. A star needs something to make an entrance ON.'},
 {q:'A ghost drops her microphone mid-song. What happens?',a:['IT BREAKS','IT FLOATS','ENCORE','SHE BLAMES YOU'],right:3,reply:'Stars don’t DROP things, darling. The floor simply fails to catch them.'},
 {q:'Think very carefully. Who gets the biggest spotlight?',a:['METTALOT','METTALOT','METTALOT','METTALOT'],right:-1,reply:'Correct! And correct! And correct! What a brilliant audience.'},
 {q:'What does Blooky play best?',a:['TEARS','KEYBOARD','THE FLOOR','ALL OF THESE'],right:3,reply:'Correct. He’s very talented. Most of the talent is damp.'},
 {q:'What makes a duet actually work?',a:['LOUDER SOLO','LISTENING','MORE LASERS','TWO SOLOS'],right:1,reply:'…Fine. Yes. That one. If anybody asks, I said lasers.'},
 {q:'What does a ghost wear to bed?',a:['BOO-JAMAS','ARMOR','THE CURTAIN','GLITTER'],right:0,reply:'BOO-JAMAS! Blooky wrote that one. Laugh, please. He’s RIGHT there.'},
 {q:'After tonight, this show is going…',a:['TO THE TOP','TO BED','ON TOUR','IN YOUR HEART'],right:-1,reply:'All correct! Personally, I’ll take whichever one has a dressing room.'}
]
// @@ end

// @@ mettalot-D003 — opening
// Type: dialogue/data bank. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 75.
opening=[
 ['Oh! Someone’s actually here! Stand there. The waterfall makes a gorgeous backdrop.',0],
 ['I’m Mettalot. Remember it, because one day it’ll be on every poster in the capital.',2],
 ['Tonight it’s just three strings and two gloves. That’s plenty. Let’s give you a SHOW!',1]
]
// @@ end

// @@ mettalot-D004 — soloStories
// Type: dialogue/data bank. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 80.
soloStories=[
 ['I rehearsed that entrance all week. Were the gloves convincing? Actually, don’t answer.',1],
 ['The echo flowers repeat everything I sing. Lovely fans. Terrible critics.',4],
 ['One day I’ll have real legs. Shoes that go CLICK on a real stage… can you imagine?',5],
 ['Someone left a magazine here once, with a stage in it all lit up. I kept the page.',5],
 ['Blooky can hear me practicing from his house. He swears that isn’t a complaint.',0],
 ['I used to sing very, very quietly. It’s easy to be invisible when you help.',5],
 ['Someday I’ll have a dressing room. For now, I have a very supportive rock.',4],
 ['I put posters up all over Waterfall. The rain took every single one. So I sang LOUDER.',2],
 ['A small crowd still gets the whole finale. I don’t do half a show.',7],
 ['Blooky’s out there somewhere, listening. He always is. He just doesn’t clap.',0]
]
// @@ end

// @@ mettalot-D005 — duetStories
// Type: dialogue/data bank. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 92.
duetStories=[
 ['Look at this! A real duet! Two ghosts making enough noise for a whole town!',2],
 ['…oh… i didn’t think anybody would stay for my part…',8,'blook'],
 ['Then sing it louder, Blooky. Nobody can hear you if you hide behind me.',0],
 ['…i was saving the little lights for my room… they look nicer out here…',11,'blook'],
 ['The gloves are improvising now. If anyone asks, that was choreography.',4],
 ['I still want the big stage. But I think I’d miss this sad, soggy little one.',0],
 ['Chin up, darling. There’s always a good angle. ALWAYS.',1],
 ['If anyone asks what happened down here tonight… tell them we were magnificent.',7]
]
// @@ end

// @@ mettalot-D007 — confirm
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 120.
confirm(){
  if(this.state==='dead'&&(this.deathAge||0)<1.8)return;
  if(this.paused||['won','dead','attack','rhythm'].includes(this.state))return;
  this.active();
  if(this.state==='dialogue'){if(this.display<this.text.length){this.display=this.text.length;return;}if(this.pages.length){this.nextPage();return;}if(this.next==='attack')this.startAttack();else if(this.next==='won')this.win();else this.toMenu();return;}
  if(this.state==='menu'){this.option=0;this.state=['pose','act','item','mercy'][this.selected];this.time=0;this.emit('select');return;}
  if(this.state==='pose'){
   const accuracy=1-Math.abs(this.poseCursor()-384)/285,score=Math.round(15+Math.max(0,accuracy)*35);this.addRating(score,accuracy>.86?'COVER SHOT':'STRIKE A POSE');this.minigames++;this.glovePose=15;this.message([[accuracy>.86?'OHHH, yes! THAT’S a cover photo! You have cheekbones in your SOUL!':'Lovely! Maybe a little less “deer in the headlights” next time.',accuracy>.86?1:4]],'attack');return;
  }
  if(this.state==='act'){const id=ACTS[this.option];if(id==='RHYTHM'||id==='DANCE')this.startRhythm(id==='DANCE');else if(id==='QUIZ')this.startQuiz();else this.startShuffle();return;}
  if(this.state==='item'){if(!this.items)return;this.items--;this.hp=Math.min(this.maxHP,this.hp+18);this.addRating(0);this.emit('heal');this.message([['Imaginary popcorn! Nobody knows how the butter gets on your fingers. It just does.',0]],'attack');return;}
  if(this.state==='mercy'){this.addRating(this.option?15:20,this.option?'GRACIOUS BOW':'APPLAUSE');this.message([[this.option?'A bow? Already? Darling, we haven’t even broken anything expensive yet.':'Applause? For ME? …Well, obviously for me. Keep it coming!',1]],'attack');return;}
  if(this.state==='quiz'){this.answerQuiz(this.option);return;}
  if(this.state==='shuffle'&&this.shuffleStage==='guess'){const good=this.cards[this.option]===this.starCard;this.addRating(good?75:-10,good?'KEEN EYES':'NICE TRY');this.shuffleStage='reveal';this.shuffleResult=good;this.shuffleSelected=this.option;this.time=0;this.emit(good?'good':'miss');}
 }
// @@ end

// @@ mettalot-D008 — toMenu
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 135.
toMenu(check=true){
  this.bullets=[];this.laser=false;this.stopped=false;this.angle=this.angleTarget=0;this.arena={x:174,y:310,w:420,h:180};this.soul.lane=1;this.soul.y=this.laneY(1);this.soul.x=384;this.state='menu';this.option=this.selected;this.time=0;this.idle=0;
  if(!check)return;
  this.menuTime=0;this.menuDrain=0;
  if(this.rating>=FINALE_RATING&&this.phaseTwoSeen&&DUET_PATTERNS.every(p=>this.completedPatterns.has('2:'+p))&&!this.finalStarted){this.finalStarted=true;this.finalBase=this.rating;this.message([['SEVENTEEN-FIFTY! They’re still watching! They’re STILL WATCHING!',3],['Blooky! The BIG number! Two thousand before the curtain drops. Give it everything!',7],['…i brought the little lights… just in case…',11,'blook'],['Then turn on EVERY one.',7]],'attack');return;}
  if(this.rating>=PHASE_TWO_RATING&&!this.phaseTwoSeen){this.phaseTwoSeen=true;this.phase=2;this.message([['Seven hundred and fifty…? That’s… that’s more than just the echo.',3],['BLOOKY! Come out! You promised you’d help if anyone actually stayed!',2],['…oh… um. hi… i hope two of us isn’t too much…',8,'blook'],['Too much? Darling, that’s a DOUBLE FEATURE.',1]],'menu');}
 }
// @@ end

// @@ mettalot-D009 — this.say
// Type: event. Source: ` engine.js `; owner ` startQuiz `; script line 142.
this.say('Quiz time! Four answers. One host. Only a LITTLE biased.',4)
// @@ end

// @@ mettalot-D010 — answerQuiz
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 143.
answerQuiz(i){
  if(this.state!=='quiz')return;const correct=i>=0&&(this.question.right===-1||i===this.question.right);this.addRating(correct?20:-10,correct?'CORRECT!':'WRONG!');this.quizScore+=Number(correct);this.quizCompleted++;this.emit(correct?'good':'miss');this.quizQuestion++;
  if(this.quizQuestion>=3){this.message([[this.question.reply,correct?1:4],[this.quizScore===3?'Three out of three! You’re hired. You’ll be paid in applause.':'Educational AND entertaining. Honestly, I spoil you.',2]],'attack');return;}
  this.say(correct?this.question.reply:i<0?'Say SOMETHING! A wrong answer beats dead air.':'Wrong! But you said it like you meant it, and that’s half of show business.',correct?1:4, 'mettalot',2.3);this.question=QUIZ[this.quizIndex++%QUIZ.length];this.time=0;this.option=0;
 }
// @@ end

// @@ mettalot-D011 — this.say
// Type: event. Source: ` engine.js `; owner ` startRhythm `; script line 150.
this.say(dance?'Copy the gloves! Same beat. MORE attitude!':'Notes from four directions! Hit each one as it crosses the pink line!',2)
// @@ end

// @@ mettalot-D012 — this.say
// Type: event. Source: ` engine.js `; owner ` startDance `; script line 167.
this.say('My turn first. Watch the gloves… then hand it back to me with STYLE.',2)
// @@ end

// @@ mettalot-D013 — this.say
// Type: event. Source: ` engine.js `; owner ` updateDance `; script line 179.
// Trigger:  if this.danceStage==='watch'  →  if step>=phrase.length 
this.say('Now you, darling!',1,'mettalot',1.2)
// @@ end

// @@ mettalot-D014 — this.message
// Type: event. Source: ` engine.js `; owner ` updateDance `; script line 183.
// Trigger:  else of this.danceStage==='watch'  →  else of this.danceStage==='repeat'&&this.time>.95  →  if this.danceStage==='rest'&&this.time>.8  →  if this.danceRound===this.dancePhrases.length 
this.message([[this.danceScore>=13?'Now THAT’S a partner! I lead, you dazzle. Somebody get a camera!':this.danceScore>=8?'A few extra steps in there. Nobody can prove they weren’t on purpose.':'We’ll call that “interpretive.” Nobody argues with interpretive.',this.danceScore>=8?2:4]],'attack')
// @@ end

// @@ mettalot-D015 — this.say
// Type: event. Source: ` engine.js `; owner ` updateDance `; script line 184.
// Trigger:  else of this.danceStage==='watch'  →  else of this.danceStage==='repeat'&&this.time>.95  →  if this.danceStage==='rest'&&this.time>.8 
this.say(this.danceRound===3?'Last phrase! Don’t look at your feet. You don’t HAVE feet.':'Again! A little longer this time!',2)
// @@ end

// @@ mettalot-D016 — this.say
// Type: event. Source: ` engine.js `; owner ` startShuffle `; script line 187.
this.say('Keep your eye on the STAR. These gloves are trained professionals. Mostly.',4)
// @@ end

// @@ mettalot-D017 — startAttack
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 193.
startAttack(){
  this.state='attack';this.time=0;this.round++;this.roundScore=0;this.bullets=[];this.timeline=[];this.hopCD=0;this.laser=false;this.stopped=false;this.soul.x=384;this.soul.lane=1;this.soul.y=this.laneY(1);this.invulnerability=.7;this.idle=0;this.menuDrain=0;this.angle=this.angleTarget=0;
  this.pattern=this.finalStarted?'final':this.phase===2?DUET_PATTERNS[this.duetTurns++%DUET_PATTERNS.length]:SOLO_PATTERNS[this.soloTurns++%SOLO_PATTERNS.length];this.duration=this.pattern==='final'?44:this.phase===2?22:18;this.attackRatingStart=this.rating;
  let lastGap=-1,lastRecord=-1;const a=this.arena,curtain=i=>{const safe=(lastGap+1+Math.floor(this.random()*2)+3)%3;lastGap=safe;const from=this.random()<.5,speed=145+this.random()*20;for(let lane=0;lane<3;lane++)if(lane!==safe)this.spawn({kind:'ribbon',x:from?a.x-24:a.x+a.w+24,y:this.laneY(lane),vx:from?speed:-speed,delay:.85,life:4.5,r:10,safe});this.safeLane=safe;this.cue='GAP '+(safe+1);this.cueTime=1;this.emit('cue');};
  const stars=i=>{const lane=Math.floor(this.random()*3),top=this.random()<.5,drift=(this.random()-.5)*40,offset=this.random()*24;for(let k=0;k<4;k++)this.spawn({kind:'star',x:a.x+25+offset+k*110,y:top?a.y-24:a.y+a.h+24,vx:drift,vy:top?110:-110,delay:.65+k*.08,life:4.5,r:8,source:k%2&&this.phase===2?'blook':'mettalot'});if(i%2===0)this.spawn({kind:'record',x:a.x+a.w+20,y:this.laneY(lane),vx:-150,delay:.8,life:4.5,r:12});};
  const tears=i=>{const xx=103+Math.sin(this.clock*.45)*8;this.spawn({kind:'tear',x:xx,y:214,vx:50,vy:42,homing:true,turn:1.5,speed:112,delay:.65,life:6.5,source:'blook',r:7});};
  const records=i=>{const lane=(lastRecord+1+Math.floor(this.random()*2)+3)%3;lastRecord=lane;const left=this.random()<.5;this.spawn({kind:'record',x:left?a.x-20:a.x+a.w+20,y:this.laneY(lane),vx:left?185:-185,delay:.7,life:4,r:12});if(i%3===2)this.spawn({kind:'record',x:left?a.x+a.w+20:a.x-20,y:this.laneY(lane),vx:left?-185:185,delay:1.1,life:4.4,r:12});if(this.phase===2)this.at(this.time+.4,()=>tears(i));};
  if(this.pattern==='ribbons'){this.say('Careful with the ribbons! Those are for the encore.',0);this.every(.5,this.duration-2,1.9,curtain);}
  if(this.pattern==='spotlights'){this.say('Pick a string! The spotlight can’t make up its mind.',1);this.every(.4,this.duration-2,2.15,i=>{const lane=Math.floor(this.random()*3);this.spawn({kind:'spot',x:a.x+a.w/2,y:this.laneY(lane),w:a.w,h:22,delay:.95,live:.65,life:1.7});this.safeLane=(lane+1)%3;this.emit('cue');});this.every(1,this.duration-2,2.0,records);}
  if(this.pattern==='records'){this.say('Vinyl! Vintage! And VERY expensive if you scratch it.',4);this.every(.5,this.duration-2,1.35,records);}
  if(this.pattern==='spin'){this.say('The stage is turning! Follow the strings, not your stomach!',4);this.every(1,this.duration-2,2.8,i=>{this.angleTarget=[Math.PI/4,-Math.PI/4,Math.PI/2,-Math.PI/2,0][Math.floor(this.random()*5)];this.cue='THE STRINGS TURN';this.cueTime=1.4;});this.every(.4,this.duration-2,2.15,curtain);if(this.phase===2)this.every(2,this.duration-3,2.0,tears);}
  if(this.pattern==='duet'){this.say('I’ll take the high notes. Blooky, try not to say sorry during the low ones.',2);this.every(.5,this.duration-3,2.15,curtain);this.every(1.6,this.duration-3,2.0,stars);this.at(7,()=>this.say('…sorry… that was supposed to be a harmony…',8,'blook'));}
  if(this.pattern==='tears'){this.say('Blooky, they love it! Those are happy tears. …Right?',3);this.every(.4,this.duration-3,.9,tears);this.every(2.6,this.duration-3,2.8,curtain);this.at(6,()=>this.say('…they’re… very enthusiastic tears…',9,'blook'));}
  if(this.pattern==='laser'){this.say('STOP! Wrong choreography! Everyone look at ME.',6);this.every(.3,5.6,1.3,stars);this.at(5.9,()=>{this.stopped=true;this.cue='EVERYBODY… HOLD!';this.cueTime=1;this.emit('stop');});this.at(7,()=>{this.stopped=false;this.laser=true;this.say('Now follow the pretty little light!',6);this.emit('laser');});this.every(8,this.duration-3,1.45,tears);this.every(10,this.duration-4,2.5,stars);}
  if(this.pattern==='final'){
   this.phase=2;this.phaseTwoSeen=true;this.say('Every light! Every note! EVERYBODY!',7);
   this.every(.7,13,1.9,curtain);this.every(2,13,2.1,stars);
   this.at(13,()=>{this.angleTarget=Math.PI/4;this.say('…i think they can hear us outside…',11,'blook');});
   this.every(13.5,27,1.0,tears);this.every(14,26,2.5,records);
   this.at(19,()=>{this.angleTarget=-Math.PI/4;this.say('Then let’s give them something worth hearing!',2);});
   this.at(26,()=>{this.angleTarget=0;this.stopped=true;this.say('One more cue. Hold your applause…',6);});
   this.at(27.4,()=>{this.stopped=false;this.laser=true;for(const b of this.bullets)b.life=b.age+6;this.say('No, DON’T hold it! Let them HEAR you!',7);});
   this.every(28,40,1.1,tears);this.every(29,39,2.0,stars);
   this.at(34,()=>this.say('…keep going… we’re so close…',11,'blook'));
   this.at(40,()=>{this.bullets=[];this.laser=false;this.say('That’s us, Blooky. That’s really, truly us.',5);});
  }
  this.timeline.sort((a,b)=>a.t-b.t);this.emit('wave');
 }
// @@ end

// @@ mettalot-D018 — finishAttack
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 238.
finishAttack(){
  if(this.finalStarted){this.finalFinished=true;this.rating=Math.max(VICTORY_RATING,this.rating);this.peak=Math.max(this.peak,this.rating);this.message([['TWO THOUSAND! We did it! I… oh, my gloves are shaking.',3],['…that was nice… could we… do it again sometime…?',11,'blook'],['Yes. Yes, Blooky. We can.',5],['And when I get my big stage, there’s a seat for you. Front row. Center.',0]],'won');return;}
  this.completedPatterns.add(this.phase+':'+this.pattern);this.addRating(35,'SHOW MUST GO ON');this.bullets=[];this.angleTarget=0;const story=this.phase===2?duetStories:soloStories,turn=this.phase===2?this.duetTurns:this.soloTurns;const line=story[(turn-1)%story.length];this.message([line],'menu');
 }
// @@ end

// @@ mettalot-D019 — this.message
// Type: event. Source: ` engine.js `; owner ` update `; script line 259.
// Trigger:  if this.state==='rhythm'  →  if this.time>=this.rhythmStart+BEAT*24+.8 
this.message([[this.rhythmScore>270?'Even the waterfall wants to dance now! You’ve embarrassed nature itself.':this.rhythmScore>120?'Lovely! A little reckless. I adore reckless.':'Well! That was certainly… LIVE.',this.rhythmScore>120?2:4]],'attack')
// @@ end

// @@ mettalot-D020 — this.say
// Type: event. Source: ` engine.js `; owner ` update `; script line 263.
// Trigger:  if this.state==='shuffle'  →  if this.shuffleStage==='cover'  →  if this.time>=this.swaps.length*.8+.5 
this.say('Which glove has the star? Choose, darling!',4)
// @@ end

// @@ mettalot-D021 — this.message
// Type: event. Source: ` engine.js `; owner ` update `; script line 265.
// Trigger:  if this.state==='shuffle'  →  if this.shuffleStage==='reveal'&&this.time>1.7 
this.message([[this.shuffleResult?'You followed the hands! And they swore these blankets were foolproof.':'The star was under THAT one. Never trust a glove in show business.',this.shuffleResult?3:4]],'attack')
// @@ end

// @@ supplementary — reactive lines from the archive's "Additional text" ledger
// These live outside the banks above. Find `old` at `where` and replace it with `new`.
const SUPPLEMENTARY_LINE_REWRITES=[
 {id:'mettalot-T063',where:'entry / inline / arena · text(game.finalStarted?\'The whole waterfall is listening.\':game.phase===2?\'Two ghosts. One very loud dream.\':\'Three strings. Your name in th',
  old:'The whole waterfall is listening.',
  new:'Every echo flower in Waterfall is listening.'},
 {id:'mettalot-T064',where:'entry / inline / arena · text(game.finalStarted?\'The whole waterfall is listening.\':game.phase===2?\'Two ghosts. One very loud dream.\':\'Three strings. Your name in th',
  old:'Two ghosts. One very loud dream.',
  new:'Two ghosts, and both of them are singing.'},
 {id:'mettalot-T065',where:'entry / inline / arena · text(game.finalStarted?\'The whole waterfall is listening.\':game.phase===2?\'Two ghosts. One very loud dream.\':\'Three strings. Your name in th',
  old:'Three strings. Your name in the lights.',
  new:'Three strings and a ghost who wants her name in lights.'},
 {id:'mettalot-T086',where:'entry / inline / endScreen · p.textContent=game.state===\'won\'?game.result+\'\\nMettalot got her audience. Blooky stayed for the encore.\': \'Even stars need a second take. Y',
  old:'Even stars need a second take. Your seat is still here.',
  new:'Even stars need a second take. Your seat’s still warm.'},
];
// @@ end
