// Ant Tenna + Spamson — The Next Big Thing
// Drop-in dialogue rewrite for Purple Soul. Generated against the 9 Oct 2026 archive.
// Each block between "// @@ <id>" and "// @@ end" replaces the archive block of the same id.
// Only quoted text changed: code, indices, face/pose numbers, speaker tags, destinations,
// bank lengths, template expressions and control/label strings are byte-for-byte the originals.

// @@ spamtenna-D003 — SHOP_TALK
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 446.
SHOP_TALK={
 'LOBBY COCOA':{seller:'RILL',browse:'Hot cocoa! Ten HP, and I promise there’s no capture net at the bottom of the cup.',bought:'One cocoa! Careful, it’s hot. Being a hero doesn’t make your tongue fireproof.'},
 'STARFAIT':{seller:'RILL',browse:'Eighteen HP in layers! The little star on top is edible. The wrapper is just optimistic.',bought:'A starfait for our rising star! Please bring the spoon back. It’s my only one.'},
 'HERO SANDWICH':{seller:'RILL',browse:'Thirty HP! A full meal for somebody who keeps walking out halfway through the performances.',bought:'One hero sandwich! You can be the competition AND a valued customer!'},
 shield:{seller:'VEX',browse:'Start with Left Guard, then upgrade to Tri Guard! Tier two blocks from above and below too. All sides share one recharge. Lasers are NOT covered by the warranty.',bought:'Guard fitted! Point the covered side at trouble. Point the receipt away from trouble.'},
 burst:{seller:'VEX',browse:'More shots before the pause! Five with the first upgrade, seven with the second. Generators still take five regular hits.',bought:'Burst expanded! More opportunities per squeeze! Very persuasive.'},
 charge:{seller:'VEX',browse:'Charge faster, fire faster! First upgrade: 0.55 seconds. Second: 0.35. Same big piercing shot.',bought:'Quick Charge installed! Now THAT’S a short sales cycle.'},
 cooldown:{seller:'VEX',browse:'Burst recovery in 0.22 seconds! The neighbors have unlimited enthusiasm. Your trigger finger deserves a break.',bought:'Rapid Recovery installed! Come back faster. Ideally to this counter.'},
 grace:{seller:'VEX',browse:'Second Wind gives you 0.95 seconds of invulnerability after a hit. Plenty of time to get your feet back under you.',bought:'Second Wind fitted! Everyone deserves a second chance. Some chances just come with a price tag.'},
 skates:{seller:'VEX',browse:'Twenty percent faster along the strings, and quicker lane changes too! No wheels touch the floor. Boing complained anyway.',bought:'Lane Skates fitted! Now you can leave a little faster. AFTER you pay.'},
 magnet:{seller:'VEX',browse:'Cash Magnet grabs exposed cash boxes within sixty pixels! You still have to bust a generator-locked box open first. No refund magnets, please.',bought:'Cash Magnet fitted! Money comes straight to you. I’m professionally jealous.'},
 bounty:{seller:'VEX',browse:'A Bonus Contract! Thirty-five gold per cash box instead of twenty-five. Pip negotiated those extra ten himself. He won’t stop talking about it.',bought:'Contract signed! Your next cash box comes with a little extra applause. Also ten actual gold.'},
 recovery:{seller:'VEX',browse:'Break eight combat targets, get two HP back! Practice targets and cash boxes don’t count. It’s a charm that claps for good aim.',bought:'Recovery Charm fitted! Turn their machinery into breathing room, eight targets at a time.'},
 pierce:{seller:'VEX',browse:'Regular shots go through one target and hit a second! One damage per hit. Your charged shots already know this trick.',bought:'Piercing Rounds loaded! Two targets, one shot. I really should’ve priced it per target.'},
 dynamo:{seller:'VEX',browse:'Got a guard? Add the Shield Dynamo! Recharge drops from 0.9 seconds to 0.45. Guard sold separately. Legally, I have to say that.',bought:'Dynamo installed! Your shield recovers twice as fast. My sales pitch, sadly, does not.'}
}
// @@ end

// @@ spamtenna-D006 — INTRO
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 479.
INTRO=[n('Hotland. An apartment lobby that has seen better decades.'),n('Homemade posters cover the mailboxes. Every single one promises the next big thing.'),m('A human...? A real, actual human? In OUR lobby?'),r('Nobody panic. Nobody shout. I’m getting the cape.'),d('You always get the cape. I’m getting the Royal Guard.'),b('Wait, wait! What if WE caught them? Picture the headline!'),m('Picture somebody outside this building humming one of my songs.'),r('Picture my brother having to buy a ticket.'),d('We’d be the ones who helped everybody get out. They’d HAVE to remember our names.'),b('“Local Comic Saves Monsterkind.” From apartment 106. Heh...'),n('The front doors swing shut. The residents shove the furniture into something like a stage.'),n('You’d like everyone to leave this in one piece. They’d like to leave it famous.')]
// @@ end

// @@ spamtenna-D007 — ENTRANCES
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 480.
ENTRANCES={
 0:[m('Hello, human. I’m Mothlark. You might know me from the elevator.'),m('The elevator never asked for a concert. It got one anyway. Several, actually.'),m('If I catch you, maybe the capital will finally ask me to sing. Into a real microphone.'),m('But first, some healing. When I win, I want it to count.'),n('Mothlark restores your HP. You have 40G, empty pockets, and a refreshment stand. ITEM opens the shop.'),m('Move left and right along a string. Up and down switches strings. And now... my opening number.')],
 4:[r('MAKE WAY! It’s Presto the Magnificent!'),b('You still owe me a curtain, Magnificent.'),r('Put it on my magnificent tab.'),r('My brother calls this a hobby. Let’s see him call it that after I catch a human.'),r('Refreshments first, of course. The audience must see me do the ENTIRE trick, fair and square.'),n('Presto heals you. Boing pays you 25G for the previous act. Spend it at the stand, and watch the marked curtains.')],
 8:[d('Stephex. Six legs. One shot. Clear the floor.'),d('My family wanted me in a nice, quiet job. So I learned to dance quietly. In the basement.'),d('I don’t want a quiet life.'),d('When they tell the story of the monster who caught a human, I want them talking about the footwork.'),d('Catch your breath. Hit the stand. I’m beating YOU, not whatever the last act left over.'),n('Stephex restores your HP. Your next performance fee is in your wallet. Footprints mark his next step.')],
 12:[b('Good evening, good evening! Why did the human cross the lobby?'),r('Because nobody managed to catch them.'),b('That... yes. Okay. That was the punchline.'),b('I’m Boing! Birthday parties, mostly. Also plumbing. Sometimes at the same party.'),b('My little sister thinks I’m already famous. I’d really like her to be right.'),b('Fresh healing! That way nobody can say I only caught you because the dancer pulled a muscle.'),n('Boing heals you and pays the performance fee. His props are ridiculous. Their warning marks are useful.')],
 16:[t('LADIES! GENTLEMEN! NEIGHBORS WHO CAME DOWN TO COMPLAIN ABOUT THE NOISE!'),t('Put your hands together for the TWO names you’re never going to forget!'),s('HEY, EVERYBODY! YOUR FAVORITE SALESMAN HAS A BRAND-NEW OFFER! ACT NOW!'),t('I’m MR. ANT TENNA! And my partner—'),s('SPAMSON! TWO HEROES! ONE UNBEATABLE PACKAGE DEAL!'),a('We made the signs ourselves! Please don’t bend them!'),t('A royal welcome! A proper marquee! A spotlight big enough for BOTH of us, folks!'),s('AND A THANK-YOU CARD FROM EVERY APARTMENT IN THE BUILDING! NO EXTRA CHARGE!'),t('Human! Take a breather. Our big opening deserves a healthy contestant!'),n('The duo restores your HP. Cash boxes now pay 25G. The Addisons sell healing and power-ups at the stand between turns.'),t('Spamson, show our guest how it works!'),s('YELLOW MEANS FIRE! PURPLE MEANS STRINGS! TAP Z FOR THREE-SHOT BURSTS. HOLD AND RELEASE FOR A CHARGED SHOT! FIRE RIGHT!'),n('Gold objects can be shot. White hazards must be dodged. Generators need five shots or one charge. Their rays will fire on EVERY string!')],
 26:[t('And THAT concludes our closing routine, folks!'),s('CONCLUDES?! TENNA, THAT WAS THE PRODUCT DEMONSTRATION!'),t('My feet disagree.'),s('I BORROWED SOMETHING FROM THE SCIENTIST’S LAB. A SHORT-TERM RENTAL.'),t('Did the scientist agree to that description?'),s('BEHOLD, THE POWER OF NEO!'),n('Spamson straightens his tie. An enormous cannon drags his other shoulder toward the floor.'),t('Spamson... that’s one arm.'),s('ONE ARM! ALL THE POWER! HALF THE STORAGE SPACE!'),t('Where is the manual?'),s('I KNOW WHAT A TRIGGER DOES!'),n('The barrel lights up. The lobby goes very quiet. This is real equipment.'),s('HEALING? ON THE HOUSE! THE SHOP HANDLES THE REST! I WANT YOU AT YOUR ABSOLUTE BEST!'),t('You could’ve consulted me about the all-string death rays, partner.'),n('HP restored. The strings turn vertical: LEFT / RIGHT switches strings, UP / DOWN travels along them. FIRE shoots UP. Addisons rush in with a timed shop during breaks. Buy and use before the short countdown ends. Cannon sweeps mark their entire path; green pockets are safe. The closing barrage has no shop break. At low HP they throw your purchased healing to you.'),t('All right! Two heroes. One arm. Feet firmly on the—')]
}
// @@ end

// @@ spamtenna-D008 — BEFORE
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 488.
BEFORE=[
 [m('Let’s start in the middle register. I’m told it carries. Notes come in phrases, and the long tails are still part of the note.')],
 [m('You can hear both parts, can’t you?'),m('The upstairs neighbor usually just hears the wall humming.')],
 [m('The royal choir has a note that lasts twelve whole bars.'),m('Mine lasts thirteen. Find the REST gap in the moving wall of sound. And please ignore my face.')],
 [m('An encore. Four words I’ve waited my whole life to hear.'),b('That was two words.'),m('Let me have this.')],
 [r('Three cups! Watch which one rattles. The balls burst out LEFT and RIGHT from that cup!')],
 [r('A magician never reveals his secrets.'),m('You labeled your curtains.'),r('A PROFESSIONAL knows the value of signage. Follow the paired IN and OUT marks. The ball comes out on the numbered string!')],
 [r('Now you see the human in THIS box... and now in THAT box!'),r('Which is a cage. The glowing EXIT marks the gap through both walls. Get out before it closes!')],
 [r('A little misdirection. A little timing. A truly heroic amount of laundry.'),r('Eyes on me, human. This one is worth the price of admission.')],
 [d('Watch the footprints. The marked STEP tile is safe. Move along the string AND change strings to follow it.'),d('Sounds easy. Show me.')],
 [d('The floor moves with the dancers. Tonight, the whole floor is dancing. Follow the STEP opening!'),d('If your string shifts, go with it. Don’t fight the floor.')],
 [d('Crossing steps. Everybody watches the legs.'),d('Watch the space between them.')],
 [d('Six steps. One finish. Five, six, seven, eight.'),d('If this works, my family can call the Guard and tell them about it themselves.')],
 [b('This hammer is spring-loaded. Just like my career.'),r('Your career is wedged behind a radiator.'),b('Exactly! Coiled and ready.')],
 [b('I had a joke about falling dominoes.'),b('But I couldn’t get the delivery to stand up.')],
 [b('Comedy is all about timing. The down arrows show where the anvils land. Don’t be under them!'),n('Boing glances up at the scenery.'),b('Well. Timing, and load-bearing screws. Mostly timing.')],
 [b('One last little thing!'),m('That is a very large little thing.'),b('Thanks! I’ve been working on my scale.')],
 [t('Our guest gets a practice shot! Audience, act surprised when it works!'),s('GOLD BORDER MEANS SATISFACTION GUARANTEED! WHITE OBJECTS ARE NOT COVERED!')],
 [t('An ALL-STAR CAST, folks! Follow those stars!'),s('AND MY FACE ON EVERY PROMOTIONAL BALLOON! COLLECT ALL TWELVE!'),n('Tenna’s white stars curve through the strings. Spamson’s gold head balloons shoot unless you pop them.')],
 [t('Ooh, bad take! SMASH CUT! Spamson, run the mail through the splice!'),s('EXPRESS DELIVERY! SHOOT THE GENERATOR TO OPEN ITS STRING BEFORE THE RAYS FIRE!'),n('Both halves shift together with their bullets. The controls stay the same. Gold mail carts can be destroyed.')],
 [t('Every great pitch needs a RIMSHOT!'),s('THAT’S MY CUE! DEAL! SALE! BUY NOW, PAY LATER!'),n('Tenna’s bouncing stars emit bursts. Spamson’s sales words move through the gaps. Shoot the gold words.')],
 [a('We know the cues! We rehearsed in the hallway!'),t('Signal before the ray, neighbors! Spamson, take the call!'),s('A CALL FOR YOU, KID! COMPLIMENTARY BLUE SURPRISES, FREE WITH EVERY CALL!'),n('Shoot blue Pipis before their fuse runs out. Miss one, and it releases tiny head projectiles.')],
 [t('Lights in every window! A prize on every string!'),s('I PUT MY WHOLE HEART INTO THIS OFFER, KID!'),n('The gold heart keeps firing diamonds until destroyed. Tenna’s window rays have separate generators.')],
 [s('VACUUM-PACKED VALUE! COME CLOSER, KID! CLOSER!'),t('A PHYSICAL CHALLENGE! Keep moving while he inhales!'),n('Spamson pulls you right. You can push back. Tenna’s footprints and cuts demand lane changes and room along the string.')],
 [t('Dance channel! Cooking channel! Shooting gallery! It’s a DOUBLE FEATURE, folks!'),r('That had better not be my actual curtain.'),s('AND EXPRESS MAIL BETWEEN EVERY PROGRAM! SAME-DAY DELIVERY!'),n('Tenna switches the stage challenge. Spamson keeps delivering carts, heads and timed Pipis. The channels do not pause his attacks.')],
 [t('Imagine it, Spamson. Our names, right above the doors.'),s('SAME SIZE LETTERS. SAME SIZE STAR.'),t('Mine could be a little higher. For visibility.'),s('WE’LL GET YOU A STOOL!')],
 [s('WE’RE STILL OPEN FOR BUSINESS, KID!'),t('Nobody caught you on their own. But we’ve got each other!'),s('TWO BIG SHOTS! TWO HEROES! ONE FINAL OFFER!'),a('Come on, boys! We believe in you!')],
 [s('NO REFUNDS! NO HESITATION! NO—'),t('No idea how to turn it off?!',1)]
]
// @@ end

// @@ spamtenna-D009 — AFTER
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 517.
AFTER=[
 [m('You stayed for the whole phrase. Most people get off at their floor.')],
 [m('That harmony sounded better with someone answering it.'),m('Don’t make me sentimental. I’m supposed to be capturing you.')],
 [m('That wasn’t a voice crack. That was a key change.'),b('A very brave key change.')],
 [m('All right. You win. My throat needs to sit down.'),m('If I ever sing somewhere else... you can stand in the back. No cage. I promise.')],
 [r('You followed the mark! That was supposed to be the subtle part!')],
 [r('The curtain is SUPPOSED to distract you.'),n('Presto checks whether his ears are poking over the top.')],
 [r('I was assured this cage is escape-proof.'),b('By the guy who sold you the cage?'),r('...By the guy who sold me the cage.')],
 [r('A magnificent escape! Which was, naturally, the OTHER half of the act.'),r('My brother is never hearing about the first half.')],
 [d('Good. You looked ahead. That’s a step worth keeping.')],
 [d('You kept your balance. I almost want to clap.')],
 [d('I felt that dodge. There’s a dancer in you somewhere.')],
 [d('Enough. You kept up.'),d('Next time, come to a show where the prize is just applause.')],
 [b('The spring missed you. It did NOT miss the plant.'),n('The plant appears unharmed and deeply inconvenienced.')],
 [b('See? The delivery’s getting better.'),m('The dominoes are on the floor.'),b('Right where I wanted them!')],
 [b('No audience members were harmed in the making of that joke.'),r('A curtain was.'),b('Your curtain has great comedic instincts.')],
 [b('Okay. I surrender. You sat through my entire act.'),b('Don’t tell my sister the hero thing fell through. Tell her the show ran long.')],
 [s('NICE SHOT! TESTING COMPLETE! WARRANTY OFFICIALLY VOID!'),t('Which means NOW the real show starts!')],
 [t('Did you see that teamwork, folks?'),s('THE HUMAN SAW IT! THAT’S WHY THEY MOVED!')],
 [t('That receiver cost me three weeks of tips.'),s('AN INVESTMENT IN AUTHENTIC DRAMATIC TENSION!')],
 [s('THE FINE PRINT WAS NOT SUPPOSED TO BE FLAMMABLE!'),t('Well, it’s a lot easier to read now!')],
 [a('Do we still clap when they miss?'),t('ESPECIALLY when we miss!')],
 [s('YOU KEEP FINDING OPENINGS, KID.'),s('MOST CUSTOMERS DON’T GET THIS MUCH PERSONAL ATTENTION!')],
 [t('Same team. Different lead. Nobody gets left behind!'),s('PUT THAT ON THE MARQUEE!')],
 [m('They fit my phrase around his curtains.'),d('And my steps. They actually listened.'),b('Did they listen to my invoice?')],
 [t('You know, folks, I can almost see the crowd outside.'),s('THEY’LL COME. WE JUST NEED OUR MOMENT.')],
 [n('The duo’s last regular routine ends. They’re still smiling. Mostly.'),t('We gave them everything, Spamson.'),s('EVERYTHING IN THE STANDARD PACKAGE.')]
]
// @@ end

// @@ spamtenna-D010 — ACT_TEXT
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 545.
ACT_TEXT={
 bribe:[n('You offer Spamson 20G to turn the power down for one round.'),s('A SPONSORED DEMONSTRATION! TENNA, WE HAVE OUR FIRST INVESTOR!'),t('For twenty gold? I’ll dim the stage lights too!'),n('All hits deal 1 damage for the next attack only. The patterns stay the same.')],
 check:{moth:[n('MOTHLARK — Good ear, no stage. Breathe Together slows her phrases. Hum a Harmony creates healing notes.')],rabbit:[n('PRESTO — Better at this than the cape suggests. Watch the Hands reveals attacks early. Be His Assistant widens cage openings.')],dancer:[n('STEPHEX — Six legs, perfect timing. Mirror the Steps lengthens footprint cues. Ask for Space steadies the moving strings.')],comic:[n('BOING — Every prop has a plan. Laugh Honestly breaks his chain reactions. Brace the Scenery shrinks falling hazards.')],duo:[n('TENNA & SPAMSON — One spotlight, two people in it. Ask for Cues gives longer warnings. Share the Spotlight slows the friends’ barricades. Hear the Pitch restores 6 HP. Bribe Spamson costs 20G: all hits deal 1 damage for the next round.')],finale:[]},
 breath:[n('You take a slow breath and wait for her to match it.'),m('Oh. I was rushing the phrase, wasn’t I?'),n('Her notes slow down. Sustained notes leave wider openings.')],
 harmony:[n('You hum the answering phrase.'),m('You know where it wants to go! Wait— stop being such a good accompanist. I’m supposed to catch you.'),n('Green harmony notes now heal you. Echo tails shorten and sustained phrases leave wider openings.')],
 watch:[n('You watch his hands instead of the cape.'),r('You have an alarming grasp of the profession.'),n('Concealed attacks reveal earlier. Marked portals stay visible.')],
 assist:[n('You offer to hold the curtain.'),r('Finally! An assistant who doesn’t eat the props.'),n('Presto leaves wider gaps around his cages and redirects fewer hidden shots.')],
 mirror:[n('You mirror his first two steps.'),d('Quick study. All right. I’ll give you the count.'),n('Footprint warnings last longer. Stephex marks the safe string.')],
 space:[n('You ask for a little more room to dance.'),d('Fair. I’ve got six feet you could step on. Nobody wants that.'),n('The strings move less. Crossing sweeps have wider openings.')],
 laugh:[n('You laugh at the joke, not at Boing.'),b('Oh! A real laugh! I completely forgot my next cue.'),n('His chain reactions lose their final link. More recovery time between props.')],
 brace:[n('You straighten the scenery brace.'),b('That’s load-bearing kindness. Thanks, pal.'),n('Falling scenery has a smaller footprint. Loose fragments become harmless confetti.')],
 cues:[n('You ask them to call their cues out loud.'),t('Ooh, a discerning audience! Spamson, give our guest the COUNT!'),s('THREE! TWO! ONE! LET’S DO BUSINESS!'),n('Spotlights, beams and Addison signs warn earlier.')],
 share:[n('You point out that the whole building is watching both of them.'),t('Both of us? You noticed?!'),s('THAT’S THE IDEA, KID. NO FINE PRINT ON THAT ONE.'),n('Their friends send slower barricades, giving you more space. Generators still need five shots or one charge.')],
 pitch:[s('A PRIVATE PRESENTATION! MY FAVORITE KIND!'),t('Tell them about the marquee, Spamson!'),s('TWO NAMES. AND A SEAT FOR EVERY FRIEND WHO GOT US HERE.'),n('You listen. The refreshments restore 6 HP. Their next routine starts gently.')]
}
// @@ end

// @@ spamtenna-D011 — FIGHT_TEXT
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 560.
FIGHT_TEXT={moth:[n('You tap the microphone stand like a challenge. Gently.'),m('An encore request? Bold. Accepted.')],rabbit:[n('You feint at his cape, pulling the swing well short.'),r('See?! The human can’t even touch me! MISDIRECTION!')],dancer:[n('You answer his flourish with a careful feint. Nothing that would hurt.'),d('A dance battle. Now we’re speaking the same language.')],comic:[n('You knock the foam hammer aside. You don’t want to hurt the guy holding it.'),b('Audience participation! My insurance is going to LOVE this.')],duo:[n('You pull your swing. It’s a show, and you want everyone walking out of it.'),s('IMPACT-RESISTANT JACKET! AVAILABLE IN ONE SIZE ONLY!'),t('Spamson, that was VERY clearly a courtesy.')],finale:[]}
// @@ end

// @@ spamtenna-D012 — MERCY_TEXT
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 561.
MERCY_TEXT={moth:[m('You can spare me after the big finish. Please. I rehearsed it.')],rabbit:[r('You can’t leave before the reveal! It would ruin the pacing!')],dancer:[d('Finish the steps with me first. Then we’re done.')],comic:[b('Just four more jokes. They all have endings, I swear.')],duo:[t('Now, now! A polite guest stays for the closing act!'),s('AND WE HAVEN’T EVEN SHOWN YOU THE PREMIUM MODEL!')],finale:[]}
// @@ end

// @@ spamtenna-D013 — ENDING
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 562.
ENDING=[
 b('...Well. NOW that’s a punchline.'),a('Spamson! Tenna! Do you both still have all your arms?!'),s('ALL ORIGINAL LIMBS! NO ADDITIONAL PURCHASE NECESSARY!',2),t('Folks... we’re going to take a short, unscheduled break.',2),n('A tiny white flag pokes out of the ruined cannon barrel. Tenna raises one of his own.'),t('We officially surrender. Please applaud at a responsible volume.',2),s('THE DEMONSTRATION HAS REVEALED A SMALL DESIGN OPPORTUNITY.',2),t('It blew up in our faces.',2),s('EXACTLY! YOU CAN SEE THE OPPORTUNITY FROM HERE!',2),a('The lab is gonna want that back.'),s('I CAN OFFER THEM A VERY COMPETITIVE RETURN POLICY.',2),m('You two actually had a good act. Before the arm.'),d('Before the arm, you two were in step.'),r('I could make the arm disappear. Permanently.'),b('Could you start with my invoices?'),t('Spamson... same size letters?',2),s('SAME SIZE STAR, PAL.',2),n('You tell them you’d come back to watch a show. One without the capture attempt.'),t('A returning audience! Did everybody hear that?!',0),s('OUR FIRST REPEAT CUSTOMER! THE REFRESHMENT STAND CALLS THAT A SUCCESS!',0),b('That’s most of MY customers.'),n('The residents open the front doors. Someone presses a homemade flyer into your hand.'),n('THE NEXT BIG THING\nAdmission: one interested neighbor.'),n('You leave the lobby. Everyone is alive. The applause follows you out.')
]
// @@ end

// @@ spamtenna-D015 — throwHealing
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 107.
throwHealing(){if(!this.final||this.hp>12||this.deliveries.length||this.clock<this.nextDelivery)return false;const item=this.items.find(i=>i.count);if(!item)return false;item.count--;this.deliveries.push({name:item.name,heal:item.heal,age:0,duration:.7,from:{x:70,y:325}});this.nextDelivery=this.clock+1.2;this.shopText=`CATCH! One ${item.name.toLowerCase()} coming your way!`;this.say('RILL: CATCH!',1.2);this.emit('delivery');return true;}
// @@ end

// @@ spamtenna-D016 — bribe
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 110.
bribe(){if(this.cash<BRIBE_PRICE){this.message([{speaker:'spamson',text:'TWENTY GOLD, KID! EVEN MY DISCOUNTS HAVE A PRICE TAG.'}],'menu');return;}this.cash-=BRIBE_PRICE;this.pendingBribe=true;this.emit('purchase');this.preAttack(ACT_TEXT.bribe);}
// @@ end

// @@ spamtenna-D019 — confirm
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 122.
confirm(){if(this.paused||this.state==='dead'&&(this.deathAge||0)<1.8)return;if(this.state==='title'){this.begin();return;}if(this.state==='dialogue'){if(this.displayChars<this.text.length){this.displayChars=this.text.length;return;}if(this.pages.length)this.showPage();else this.advance(this.next);return;}if(this.state==='menu'){this.activate(['fight','act','item','mercy'][this.selected]);return;}if(this.state==='strike'){this.gentleStrikes++;this.pose='react';this.score=1-Math.abs(this.cursor-.5)*2;this.emit('gentleStrike');this.preAttack(FIGHT_TEXT[this.actor]);return;}if(this.state==='shop'){this.shopAction(this.shopOptions()[this.option]?.[1]);return;}if(this.state==='options'){if(this.submenu==='item'){const item=this.items.filter(i=>i.count)[this.option];if(!item)return;item.count--;this.heal(item.heal);this.preAttack([{speaker:'seth',text:`You eat the ${item.name.toLowerCase()}. ${item.heal} HP restored.`}]);}else{const key=this.cast.acts[this.option][1];this.acts++;if(key==='bribe'){this.bribe();return;}if(key==='check')this.preAttack(ACT_TEXT.check[this.actor]);else{const repeat=!!this.flags[key];this.flags[key]=true;if(key==='pitch')this.heal(6);this.preAttack(repeat?[{speaker:'seth',text:key==='pitch'?'You sit through another pitch. 6 HP restored.':'They remember your help. Its effect is still active.'}]:ACT_TEXT[key]);}}return;}if(this.state==='snacks'){const item=this.items.filter(i=>i.count)[this.option];if(item){item.count--;this.heal(item.heal);this.state='attack';this.say('Refreshments on the house! Back to the demonstration!',2.2);}return;}if(this.state==='dead'){this.retry();return;}}
// @@ end

// @@ spamtenna-D026 — this.say
// Type: event. Source: ` engine.js `; owner ` finale `; script line 229.
// Trigger:  if this.breather  →  if this.breathIndex!==bi 
this.say(['RILL: SHOP’S OPEN! HURRY!','VEX: PANIC BUYING WELCOME!','PIP: ACT NOW! SERIOUSLY, NOW!','RILL: I’LL THROW IT! CATCH!','VEX: DEALS THIS HOT WON’T LAST!','PIP: EVERYBODY DUCK!'][bi],3)
// @@ end

// @@ spamtenna-D031 — this.game.say
// Type: event. Source: ` input.js `; owner ` key `; script line 317.
// Trigger:  if pressed  →  if this.cheat.join(',')==='up,up,down,down,left,right,left,right,b,a' 
this.game.say('The audience agrees to look the other way. Just this once.',3)
// @@ end

// @@ supplementary — reactive lines from the archive's "Additional text" ledger
// These live outside the banks above. Find `old` at `where` and replace it with `new`.
const SUPPLEMENTARY_LINE_REWRITES=[
 {id:'spamtenna-T025',where:'engine.js / shopDialogue · text:this.shopTab===\'gear\'?\'Vex has permanent upgrades! Rill has refreshments! We support our friends, and we support repeat customers.\':\'We',
  old:'Vex has permanent upgrades! Rill has refreshments! We support our friends, and we support repeat customers.',
  new:'Vex has permanent upgrades! Rill has snacks! We support our friends. We support repeat customers even MORE.'},
 {id:'spamtenna-T026',where:'engine.js / shopDialogue · text:this.shopTab===\'gear\'?\'Vex has permanent upgrades! Rill has refreshments! We support our friends, and we support repeat customers.\':\'We',
  old:'Welcome to our sponsor stand! Rill sells healing items. Vex sells power-ups. Somebody has to pay for those homemade signs!',
  new:'Welcome to the sponsor stand! Rill does healing, Vex does power-ups. Somebody has to pay for all those homemade signs!'},
 {id:'spamtenna-T166',where:'entry / inline / special · text(\'They have not agreed on who gets the credit.\',384,288,1.3,\'#bca5bb\',true)',
  old:'They have not agreed on who gets the credit.',
  new:'They still haven’t agreed on who gets the credit.'},
];
// @@ end
