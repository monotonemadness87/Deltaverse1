# Purple Soul — dialogue rewrite (voice pass)

Covers every main encounter except Encore and Rift: Mettalot, Gerson, the Tenna + Spamson lobby, Spamson NEO, Muffet, Sans (No Promises), Sans + Alphys (CORE), Flowey and Aqua. Built against the 9 Oct 2026 archive.

## How to apply

Each `.js` file holds drop-in blocks:

```
// @@ gerson-D002 — INTRO
INTRO=[ ...rewritten... ]
// @@ end
```

The id matches the block id in `Game-Dialogue-Lore-and-Character-Guide.md`. Swap the archive block for the one here. Blocks that aren't in these files are unchanged. A few files end with a `SUPPLEMENTARY_LINE_REWRITES` table of `{id, where, old, new}` entries. Those are loose lines from the archive's "Additional text" ledger, so do a find-and-replace for them.

## What was guaranteed (machine-checked)

Every block was tokenised against the original. Only the text inside quotes changed. These all match byte for byte:

- code, bank lengths and indices
- face/pose numbers, speaker tags (`'blook'`, `'aqua'`, `'n'`…) and destinations (`'menu'`, `'attack'`…)
- template expressions (`${deaths}` etc.) and leading/trailing spaces on concatenated pieces
- `\n` line-break counts in Muffet's and other multi-line boxes
- menu/ACT labels, attack names, control instructions and mechanics text (numbers, costs, HP)

Two encounter-specific checks:

- **Lobby:** `voiceFace()` picks Tenna's and Spamson's faces from keywords in the text. Every rewritten line still gets the same face.
- **Line length:** no rewritten line is longer than the longest original line in the same encounter.

Result: 2,332 strings checked, 903 rewritten, 0 errors.

## Voice choices, by character

- **Gerson:** "Bwahaha" → canon **"Wa ha ha!"**. Dropped g's ("doin'", "'em", "oughta") and "kid"/"kiddo" alongside "youngster". He gets canon touches: Undyne as a "little urchin", "I always thought the emblem just looked neat". His stalling line now openly says what he was doing: "Every word bought them a few more steps."
- **Mettalot / Blooky:** fewer "darlings" (about 12 down to 5). The vague imagery became Waterfall specifics (echo flowers as "lovely fans, terrible critics", rain washing the posters away). Blooky stays lowercase and hesitant.
- **Lobby residents:** they were all speaking without contractions, so they sounded like one voice. Each now has their own: Mothlark is earnest, Presto grandiose, Stephex clipped ("five, six, seven, eight"), Boing a groaner comic. **Tenna** gets host patter ("folks", CAPS on key words). **Spamson** is a polished salesman from the Addisons' species, not a spam email: no brackets, no misspellings, just sales talk ("BUY NOW, PAY LATER!", "SATISFACTION GUARANTEED!", "A SHORT-TERM RENTAL").
- **Spamson NEO:** the same salesman, grieving. No brackets; the grief shows in repetition and salesman habits breaking down ("I SIGNED WITHOUT READING IT", "NO COMMISSION", "I'D PAY FULL PRICE TO HEAR IT AGAIN"). His intro tagline ("THE SENSATION OF YOUR SCREEN…") and "BEHOLD, THE POWER OF NEO!" are verbatim.
- **Muffet:** canon "Ahuhuhu~", "dearie" and tildes. The six hands are counted ("two hold the frame, the other four…"). The turn 50/59/60 beats and the silent 51–58 window are untouched.
- **Sans (No Promises):** more canon cadence ("heya", "welp", "pal"). A Gaster nod ("the guy before her"). "pretty determined" became "you really don't quit", because Seth is perseverance and determination belongs to Flowey.
- **Sans + Alphys (CORE):** Alphys stammers only under pressure ("Then I'm t-taking over the CORE. All of it."). Sans gets "rotten to the core". Flowey calls him "trashbag" next to the existing "smiley".
- **Flowey:** already close to canon, so this was a light pass. "Friendliness pellets", a few "golly/gee/idiot"s, and some of the clipped three-fragment lines loosened up.
- **Aqua:** brought closer to her own Gerson line ("Geez, Seth… I'll see you around..~♡"). She's casual, teasing and cold, and uses `~♡` only three times, each one sharpening a threat. Every habit-reading line still names the same behaviour it did before.

> Note: the archive guide's voice table still says Spamson uses "bracketed/glitchy emphases". That line is out of date and should be changed so future rewrites don't bring the brackets back.

## Kept verbatim on purpose

- CORE **EPILOGUE**, your private Sans/Alphys exchange.
- CORE **ENDING**'s key claims: the combat data, "asgore's way more determined", "reset a million times". The bluff still lands the same way.
- Aqua's Gerson kill line and "I'll see you around..~♡". The "GERSON WAS KILLED / 0 EXP" result text.
- Aqua's late STORY beats, VICTORY and DEFEAT, plus Flowey's RELEASE/CUT narration and the six memory pages.
- CORE's inherited No Promises scaffolding (`base-engine.js`), which isn't current CORE speech.

## One story change to sign off on

**Aqua INTRO, line 2.** "I heard the theater go quiet. Then that thing with the crown." → "You heard the skeleton. If it takes a million tries, I want all of them." This spells out that Sans's scare tactic is why she turns on Seth, which the guide lists as an allowed bridge. If you'd rather keep the theatre/crown callback, restore the archive line. Nothing else depends on it.

## Files

`03-mettalot.js` · `04-gerson.js` · `05-tenna-spamson-lobby.js` · `06-spamson-neo.js` · `07-muffet.js` · `08-sans-no-promises.js` · `09-sans-alphys-core.js` · `10-flowey.js` · `11-aqua.js` · `before-after.txt` (every changed line, old above new)
