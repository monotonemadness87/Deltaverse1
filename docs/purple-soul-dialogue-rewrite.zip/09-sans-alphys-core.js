// Sans + Alphys — Misery Likes Company
// Drop-in dialogue rewrite for Purple Soul. Generated against the 9 Oct 2026 archive.
// Each block between "// @@ <id>" and "// @@ end" replaces the archive block of the same id.
// Only quoted text changed: code, indices, face/pose numbers, speaker tags, destinations,
// bank lengths, template expressions and control/label strings are byte-for-byte the originals.

// @@ sans-genocide-D003 — OPENING
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 1177.
// NOTE: Opening roll call (old suit / Gerson / the salesman / Muffet) and "i will finish mine." are kept; Encore is still not referenced.
OPENING=[
 ['heya, kid.',0],
 ['so alphys was working on a way to break the barrier. one that didn’t cost any more human lives.',1],
 ['asgore was scared of what your people would do if they ever found out.',4],
 ['and yet... here you are. slaughtering us anyway.',7],
 ["kinda funny, when you think about it.",1],
 ['eh. what do i know. i was never really a science guy.',4],
 ['she did have a backup plan, though. a robot built to wipe out humans. she called it NEO.',0],
 ['but you already know how that turned out. right?',1],
 ['that old suit in snowdin. gerson in waterfall. the salesman.',4],
 ["you wore the old turtle out, and your friend took the kill. real nice teamwork.",7],
 ['and muffet? what, couldn’t even clear out the infestation?',1],
 ["not sure how you plan on beating me when you couldn’t even finish the job with her.",7],
 ["...don’t worry, though.",4],
 ['i will finish mine.',7]
]
// @@ end

// @@ sans-genocide-D004 — AQUA
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 1193.
AQUA=[
 ["Scoot over, Seth. You’re taking forever with him.",0,'aqua'],
 ["Don’t look so surprised. We got out of that nest together, remember?",0,'aqua'],
 ['and here i was hoping you two would’ve split up by now.',4],
 ["guess not. you’re both rotten to the core. misery likes company, huh?",7],
 ['welp. guess it’s a party, then.',1],
 ['mind the fireworks.',7],
 ["I take one side, you take the other. Let’s see him dodge both.",0,'aqua']
]
// @@ end

// @@ sans-genocide-D005 — CALL
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 1202.
CALL=[
 ['S-Sans? Are they... still there?',0,'alphys'],
 ['yep. both of ’em. we’re just getting to know each other.',1],
 ["Okay. Then I’m t-taking over the CORE. All of it.",0,'alphys'],
 ['heh. look at that. i brought a friend too.',1],
 ["I tried to find another way. I really did. And every time, I made it worse.",0,'alphys'],
 ["I can’t take any of it back. But I can make sure you two don’t get to anyone else.",0,'alphys'],
 ["hey, bright side. you finally got an audience for all these lasers.",1],
 ["...Sans. Don’t make me laugh right now.",0,'alphys'],
 ['sorry. tough crowd.',4]
]
// @@ end

// @@ sans-genocide-D006 — BETWEEN
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 1229.
BETWEEN=[
 [
  [
   "nope. i decide when you get to swing.",
   1
  ]
 ],
 [
  [
   "they’re small. there’s a lot of ’em. do the math.",
   0
  ]
 ],
 [
  [
   "look at you, practicing your jumps. cute.",
   4
  ]
 ],
 [
  [
   "stand still. keep moving. funny how either one can get you killed.",
   1
  ]
 ],
 [
  [
   "up, down. doesn’t really matter which way you fall.",
   7
  ]
 ],
 [
  [
   "three strings, and i’m still pulling yours.",
   4
  ]
 ],
 [
  [
   "that notebook makes a lousy shield, pal.",
   1
  ]
 ],
 [
  [
   "huh. so you can break stuff that hits back. good to know.",
   4
  ]
 ],
 [
  [
   "lotta running for somebody with nowhere to go.",
   7
  ]
 ],
 [],
 [
  [
   "two of you now. guess i actually gotta pay attention.",
   7
  ]
 ],
 [
  [
   "Spread out, Seth. Let’s make him pick a favorite.",
   0,
   "aqua"
  ]
 ],
 [
  [
   "Stop following me through every gap. Get your own.",
   0,
   "aqua"
  ],
  [
   "hey. no coaching during the exam.",
   1
  ]
 ],
 [
  [
   "bet muffet was thrilled to get both of you at once.",
   4
  ]
 ],
 [
  [
   "she let you leave, pal. don’t mistake that for winning.",
   7
  ]
 ],
 [
  [
   "He keeps splitting our timing. Watch the hand, not the face.",
   0,
   "aqua"
  ]
 ],
 [
  [
   "one of you swings, the other makes me move. cute trick.",
   4
  ]
 ],
 [
  [
   "I saw where you were. I don’t need to see where you’re going.",
   0,
   "aqua"
  ],
  [
   "aw. everybody’s learning.",
   1
  ]
 ],
 [
  [
   "One opening. I’ll keep his other side busy. Don’t miss.",
   0,
   "aqua"
  ]
 ],
 [],
 [
  [
   "Every line in here has a power feed. You can’t dodge the whole room forever.",
   0,
   "alphys"
  ]
 ],
 [
  [
   "You broke a relay? Good for you. I have forty.",
   0,
   "alphys"
  ],
  [
   "she buys in bulk.",
   1
  ]
 ],
 [
  [
   "I logged where you stood last time. I’m done making the same mistakes.",
   0,
   "alphys"
  ]
 ],
 [
  [
   "congrats. you made it to the assembly line.",
   1
  ],
  [
   "There’s nothing waiting at the other end. I made sure.",
   0,
   "alphys"
  ]
 ],
 [
  [
   "I locked every door. I should’ve done that a long time ago.",
   0,
   "alphys"
  ]
 ],
 [
  [
   "Gold boxes feed the lasers. I’ll cut what I can reach.",
   0,
   "aqua"
  ]
 ],
 [
  [
   "I used to design puzzles. I always hoped somebody would like them.",
   0,
   "alphys"
  ],
  [
   "...This isn’t one of those.",
   0,
   "alphys"
  ]
 ],
 [
  [
   "easy, doc. that light show’s going on the electric bill.",
   1
  ],
  [
   "Then stop letting them survive it.",
   0,
   "alphys"
  ]
 ],
 [
  [
   "...heh. almost done.",
   8
  ],
  [
   "Don't tell them that.",
   0,
   "alphys"
  ]
 ],
 [],
 [
  [
   "Golly! Finally, something in here worth breaking!",
   0,
   "flowey"
  ]
 ],
 [
  [
   "My roots reach the floor too, you know. Use ’em!",
   0,
   "flowey"
  ]
 ],
 [
  [
   "G-get OUT of my circuits!",
   0,
   "alphys"
  ],
  [
   "Come pull me out yourself, then!",
   0,
   "flowey"
  ],
  [
   "would you two like a minute?",
   8
  ]
 ],
 [
  [
   "A little insurance. Don’t make me regret this.",
   0,
   "flowey"
  ]
 ],
 [
  [
   "Those seeds aren’t for decoration! Grab them and MOVE!",
   0,
   "flowey"
  ]
 ],
 [
  [
   "Not every target has to be a human, you know. Surprise!",
   0,
   "flowey"
  ],
  [
   "yeah. i noticed.",
   8
  ]
 ],
 [
  [
   "There! I’ve got one pinned. Shoot it already!",
   0,
   "flowey"
  ]
 ],
 [
  [
   "He’s hiding his openings behind the room. I’ll cut the feed.",
   0,
   "aqua"
  ]
 ],
 [
  [
   "...still here.",
   8
  ],
  [
   "With me, Seth. One more time.",
   0,
   "aqua"
  ],
  [
   "Don’t you DARE quit on me now!",
   0,
   "flowey"
  ]
 ],
 []
]
// @@ end

// @@ sans-genocide-D007 — ENDING
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 1525.
// NOTE: The combat-data boast, "asgore’s way more determined", and "reset a million times" stay intact so the EPILOGUE still exposes the same bluff.
ENDING=[
 ['...heh.',8],
 ["yeah. i wasn’t really here. well, i am. just not in this room.",1],
 ['man. i really was hoping to win that one.',8],
 ['guess that’s what i get for actually caring.',5],
 ["figures it’d turn out like this...",5],
 ["S-Sans... you held them here. You bought us time.",0,'alphys'],
 ["nah... i’m all tapped out. but...",5],
 ["you two? you’re still screwed. we got a whole lot of combat data out of that.",12],
 ['pretty good experiment, honestly.',12],
 ['so now i can finally take a break...',5],
 ["because asgore's way more determined than i am.",12],
 ["and if this is the best you two have got...?",12],
 ["you can reset a million times, and you'll never beat him once.",7],
 ["...Seth. We need to talk.",0,'aqua']
]
// @@ end

// @@ sans-genocide-D034 — confirm
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 844.
confirm(){
  if(this.paused||['dead','attack','cheat','dual','reveal','exit','won'].includes(this.state))return;
  if(this.state==='ready'){this.emit('music');this.message(OPENING,'attack');return;}
  if(this.state==='dialogue'){if(this.display<this.text.length){this.display=this.text.length;this.emit('voice-stop');return;}if(this.pages.length){this.nextPage();return;}this.emit('voice-stop');const next=this.next;if(next==='attack')this.startAttack();else if(next==='epilogue')this.beginEpilogue();else if(next==='won'){this.state='won';this.emit('end');}else this.menu();return;}
  if(this.state==='menu'){if(this.finalPrompt){this.state='fight';this.ally.action='FIGHT';this.ally.actionTime=99;this.time=0;return;}this.previewAlly();if(this.selected===0)this.allyTurn();this.state=['fight','act','item','mercy'][this.selected];this.option=0;this.time=0;return;}
  if(this.state==='fight'){if(this.canPair())this.resolveFight(0);else this.interruptFight();return;}
  if(this.state==='item'){if(!this.items)return;this.items--;this.hp=Math.min(this.maxHP,this.hp+18);this.emit('heal');this.allyTurn();this.message([['You eat a slice of pie. 18 HP restored.',0,'seth']],'attack');return;}
  if(this.state==='mercy'){this.allyTurn();this.message([['if you wanted to stop, you had a whole underground to do it in.',7]],'attack');return;}
  if(this.state==='act'){const entries=ACTS.slice(this.actPage*4,this.actPage*4+4);if(this.option===entries.length){this.actPage=(this.actPage+1)%3;this.option=0;this.emit('select');return;}const i=this.actPage*4+this.option;let line,speaker='sans';if(i>=4){this.useTechnique(i);return;}
   if(i===0)line='SANS · 1 ATK · 1 DEF. He’s putting everything into not getting hit.';
   if(i===1){speaker=this.allyActive?'aqua':'seth';line=this.allyActive?'I’ve got my side. You watch yours. You swing, I swing.':'Aqua has not arrived.';}
   if(i===2){speaker=this.coreActive?'alphys':'sans';line=this.coreActive?"I'm still here. Every switch in this room is mine.":"she’s busy. you two keep giving her messes to clean up.";}
   if(i===3){speaker=this.floweyActive?'flowey':'seth';line=this.floweyActive?this.interest+'% interest. Saves cost 8%, healing 12%, a return costs 25%. Keep me entertained and I might stick around.':'Something is watching beyond the cables.';}
   this.allyTurn();this.message(i===0?[[line,0,speaker],['TP: finish turns, graze danger and time paired attacks well. Spend it in ACT. Dance takes both of you.',0,'seth']]:[[line,0,speaker]],'attack');
  }
 }
// @@ end

// @@ sans-genocide-D036 — useTechnique
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 952.
useTechnique(i){
  if(i===8){if(!this.floweyActive){this.announce('FLOWEY HAS NOT JOINED',2);return;}if(this.hp===this.maxHP&&this.ally.hp===64){this.announce('BOTH HUMANS HAVE FULL HP',2);return;}if(!this.spendInterest(12,'REQUESTED HEAL')){this.announce('HEAL NEEDS 12% INTEREST',2);return;}this.hp=Math.min(this.maxHP,this.hp+12);this.ally.hp=Math.min(64,this.ally.hp+8);this.karma=Math.max(0,this.karma-2);this.pendingHealVine=true;this.emit('heal');this.allyTurn();this.message([['Ugh, FINE. Twelve percent for twelve HP. Your friend gets eight. Now move!',0,'flowey']],'attack');return;}
  const kind=['guard','focus','cut','megalo'][i-4],cost=TP_COSTS[kind];if(kind==='focus'&&!['gate','doubleTracking','doubleGate','relay','bombs','conveyor','relayMaze','tiles','prism','core','petals','hack','pin','rootGate','push','final'].includes(this.nextWaveType())){this.announce('NEXT ATTACK HAS NO YELLOW PHASE',2);return;}if((kind==='cut'||kind==='megalo')&&!this.allyActive){this.announce('AQUA MUST JOIN FIRST',2);return;}if(this.tp<cost){this.announce('NEEDS '+cost+' TP · YOU HAVE '+Math.floor(this.tp),2);return;}this.tp-=cost;
  if(kind==='megalo'){this.megaloPending=true;this.ally.menuDecision={action:'fight',target:'SANS',reason:'MEGALO DANCE · STRIKE TOGETHER'};this.ally.turnCommitted=false;this.allyTurn();this.state='fight';this.time=0;this.rewardInterest(2,'MEGALO DANCE');return;}
  this.pendingTechnique=kind;if(kind==='guard'){this.ward=1;this.floweyWard=false;}this.allyTurn();this.message([[{guard:'You brace for one hit. No HP or KR when the guard catches it.',focus:'Your next yellow phase fires stronger shots: two damage, nine when charged.',cut:'I’ll cut you an opening next attack. Try not to waste it.'}[kind],0,kind==='cut'?'aqua':'seth']],'attack');
 }
// @@ end

// @@ sans-genocide-D040 — this.message
// Type: event. Source: ` engine.js `; owner ` update `; script line 984.
// Trigger:  if ['dual','reveal'].includes(this.state)  →  if this.state==='dual'  →  if t>.45  →  else of this.finalPrompt 
this.message([[this.dodge.megalo?'...heh. caught me on the wrong foot. next one might be a little slower.':this.dualStrikes>12?'...heh. this is more exercise than i’ve had all year.':this.dualStrikes>5?'two swings. zero hits.':'guess i gotta stretch my legs for this one.',this.dualStrikes>12?8:1]],'attack')
// @@ end

// @@ sans-genocide-D042 — ANOMALIES
// Type: computed dialogue. Source: ` story.js `; owner ` ANOMALIES `; script line 1213.
function ANOMALIES(deaths){return [
 ['...you’re still here, huh?',8],
 ["S-Sans. The instruments just logged "+deaths+" timeline "+(deaths===1?'anomaly.':'anomalies.'),0,'alphys'],
 [deaths===0?"Nobody’s died this run. But something outside this room is h-holding on to it.":"They die. They come back. The same two humans, over and over again.",0,'alphys'],
 ['you two...?',5],
 ["no... somebody’s helping you.",7],
 [deaths>=6?"heh. "+deaths+" times. guess i’m better at my job than i thought.":deaths>0?"guess somebody’s not a fan of my work.":"somebody’s got their finger on the reset button.",8],
 ["Hee hee hee. Took you long enough, trashbag.",0,'flowey'],
 ["I'm not letting you end my game, smiley.",0,'flowey'],
 ["Keep pushing, you two. I’ll keep bringing you back... as long as it stays interesting.",0,'flowey'],
 ["100% interest. Saves cost 8%, healing costs 12%, each return costs 25%. Run out, and we're starting over.",0,'flowey'],
 ["So you’re the one bringing us back. Interesting.",0,'aqua'],
 ["Who else, genius? Now quit staring and give me a show!",0,'flowey'],
 ['alright. so everybody brought a friend.',8],
 ["let's see how long this party lasts.",7]
];}
// @@ end

