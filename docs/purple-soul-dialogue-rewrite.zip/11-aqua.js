// Aqua — Last Playmate
// Drop-in dialogue rewrite for Purple Soul. Generated against the 9 Oct 2026 archive.
// Each block between "// @@ <id>" and "// @@ end" replaces the archive block of the same id.
// Only quoted text changed: code, indices, face/pose numbers, speaker tags, destinations,
// bank lengths, template expressions and control/label strings are byte-for-byte the originals.

// @@ aqua-D001 — NEMESIS_LINES
// Type: dialogue/data bank. Source: ` nemesis-dialogue.js `; owner ` modules["nemesis-dialogue.js"] `; script line 710.
NEMESIS_LINES={
 director_camp:L('Ooh, cozy spot. Let’s see how long it stays cozy.','You haven’t moved off that patch of floor in a while, Seth.','Standing still saves you a decision. Don’t worry. I’ll make one for you.','Why would I cover the whole room? I only need that one spot.','You’re just waiting for me to miss. That’s kind of sweet.','There it is. Your favorite place~'),
 director_shuffle:L('Left, right... and you’re still in the same place.','All those tiny steps, and you haven’t gone anywhere.','Your feet are moving. You aren’t.','That whole little dance fits under one throw, you know.','Back and forth, back and forth. Geez. Let’s change the floor.','Wiggling around in a hiding place doesn’t make it a new one.'),
 director_loop:L('I know where that circle ends up. Same place as last time.','You already showed me the next corner. Thanks!','Same little tour again? I could give it myself by now.','Go ahead. I’ll meet you on the way around.','That route saved you once, so now you trust it. Cute.','You made yourself a path. I only have to close one piece of it.'),
 director_learned:L('This one got you before. Remember?','You still don’t have an answer for this one, do you?','I remember which throw made you flinch. I kept it.','You’re the one who taught me what to keep.','Let’s do the part you didn’t like again~','I watched what happened last time. I’m using it.'),
 fight:L('Okay, enough watching. My turn.','You’ve still got something left. Show me.','Oh, you brought a notebook? I brought a knife.','Eyes on my hand, Seth. Not my face.','Let’s see what you do when I get closer.','Finally. A real decision.'),
 check:L('Hold on. Let me count.','Your bag’s looking a lot lighter.','You checked my numbers. I can check yours too.','I want to know which one you think is gonna save you.','You’ve been very careful with that last one, huh?','I don’t guess, Seth. I look.'),
 bleed:L('Just a little cut. Something to remember me by..~♡','You packed snacks. Let’s give you a reason to eat them.','It doesn’t have to be deep. It just has to keep hurting.','You can stop the bleeding. It’ll cost you something.','There. Now you’ve got one more thing to decide.','Patience works so much better when you’re uncomfortable.'),
 slow:L('Your hands are awfully busy.','You keep throwing stuff at me. Let’s slow that down a little.','One at a time, okay? You’ll get your turn.','You keep reaching before you’re ready.','All that hurrying. Where’s it gotten you?','Hold it properly. I’m in no rush.'),
 read:L('I’m watching where you go right after the warning.','Same opening, same answer. Every time.','Go ahead and change your mind. I’m counting on it.','I don’t need to know everything about you. Just your next step.','Your feet always answer before you do.','Keep moving. That’s the part I’m reading.'),
 pin:L('You really like that patch of floor, huh?','Let me stitch you into it.','Better move before it tightens. See? I’m being helpful.','Favorite places are so easy to find.','You can leave. You just have to do it properly.','There. Now you’ve got something to pull against.'),
 guard:L('You’re gonna throw again. I can tell.','I’ll keep this hand free for that.','Go on, spend the small one first. See if I bite.','You don’t get that opening twice, Seth.','I can afford to catch a little of it. Can you?','Go on. Test it.'),
 recover:L('Give me a second. My legs are shaking.','Geez. You’re making me work for it.','I can breathe without asking you first.','That was a LOT of running.','You can stop counting my food. This isn’t food.','I need steady hands for this. One moment.'),
 focus:L('Okay. One thing at a time.','Less noise. Better aim.','You move around. I’ll pick where to look.','I was trying to watch everything at once. That was silly of me.','The knife only needs one place to land.','Let’s make this next one count.'),
 pressure:L('You take the loveliest long turns, Seth.','The menu’s still in the room with me, you know.','Pick something. I already did.','I’ll give you a moment. A shorter one this time.','You can eat or you can think. Better be quick either way.','Those buttons never promised you a quiet room.'),
 feint:L('You saw an opening. Did you see me leave it there?','Go on, give me your usual answer.','I’ll show you my hand. Just not all of it.','You’re getting really good at the first warning.','I can change my mind before I throw. So can you.','Watch closely. This one’s a question.'),
 heal:L('What? I brought these for me.','Ow. Okay, that one hurt. I’m eating.','You didn’t think I’d leave the good piece, did you?','Just a little bite. No point wasting it.','I’m still standing. Don’t look so pleased with yourself.','We BOTH get an inventory, Seth.'),
 corner:L('You keep backing up to the edge.','That corner isn’t yours, you know.','You move away from me, and then the wall does my job for me.','I’ve seen where you go when the room gets loud.'),
 direction:L('You go that way a lot, huh?','I’m starting to recognize the answer.','You’ve got a rhythm. Did you know?','It’s the step right after the warning. That’s the interesting one.'),
 changed:L('Oh? That was different.','You changed your answer. Good.','Huh. I was waiting in the wrong place.','Okay. I’ll just watch again.','You noticed what I noticed.','Keep doing that. I might actually have to think.'),
 aggression:L('You’re trying to rush me.','That isn’t an opening. You just want it to be.','You keep choosing FIGHT. I can work with that.','Every throw costs you a little time, you know.','You’re way more interesting when you chase me.','You want me to hold still. I know.'),
 wounded:L('Ow. Okay, that one counted.','I didn’t leave that opening. You made it.','...Yes. I felt it.','You got through. Once.','I’ll remember which hand did that.','Don’t celebrate yet. I’m still here.'),
 'bound':L('You changed my color. Rude.','You like deciding how other people move. Huh.','Four exchanges. I can count to four.','That was clever. Don’t spoil it by smiling.','I’m still me in here. Even on your strings.'),
 'interrupted':L('You touched my menu. Again.','I already picked!','Fine. That one doesn’t happen, then.','You can stop an ACT. You can’t stop me looking.','You found the button before I did.'),
 'fake-save':L('You reached for it. I saw.','That word really means something to you, huh?','A promise on a little button. How sweet.','I wondered if you’d believe me. You did~'),
 'save-refused':L('You didn’t even touch it.','You recognized that trick.','Okay. So you learn too.','You could have pretended to be surprised.'),
 retry:L('There you are again.','You came back! You really do like this game.','I’ve seen that look before.','The room starts over. Your habits don’t.'),
 deathKnife:L('The knife got there before you did.','You kept moving after the opening closed.','You waited for one more warning. It didn’t come.','I remember where you stopped.'),
 deathGreen:L('Your shield was looking somewhere else.','You can turn the shield. You just have to turn it in time.','You watched my hand and missed the other direction.','That color held you still. I didn’t.'),
 deathMenu:L('You were still picking.','That button didn’t keep you safe.','You took your sweet time with that menu.','You can think, and you can move. You’ll need both.'),
 deathFinal:L('You made it all the way back to that last room.','So close. I could feel you getting impatient.','You know the last colors now.','You reached the end. You didn’t finish it.'),
 rematch:L('I remember the knife at the end.','You got through me before. You’ll have to do it again.','I know what comes after that look.','You’ve already seen me lose. Stop waiting for me to make it easy.'),
 familiarBind:L('Last time, you liked the strings.','You used my color against me before.','I remember you reaching for BIND.','You’re gonna try to pick my footing again, aren’t you?'),
 familiarFood:L('You brought the bag again.','You know exactly when you like to eat.','Last time, you kept something for the end.','I remember how carefully you counted the food.'),
 first:L('You’ve got four buttons. So do I.','Watch mine. I’m gonna use them.','I can spend a turn thinking, too.','You don’t get to choose for both of us.'),
 late:L('I’m running out of answers.','Your hands are shaking. Mine, too.','I can feel the weight of every throw now.','I’m still choosing. Don’t take that from me.','You keep making me change the plan.','I thought you’d be easier to read by now.'),
 stubborn:L('Okay, wrong pick. It happens.','You made that answer expensive.','I’m not doing that one again. Not yet.','You were ready for me.','Let me try a different question.','You didn’t do what I expected.'),
 defeat:L('That was the place you always went.','You almost changed your mind.','I had to work for that one.','I wonder which part you’ll remember.','I’m going to remember this.','You’ll come back with an answer. I know.'),
 sequence:L('Left, then right. You like pairs.','Switching direction is part of the pattern too.','I’m watching the step after the step.','You alternate. That doesn’t make you random.','You changed sides exactly when I expected.','A little routine. You didn’t know you had one.'),
 learnedCounter:L('That worked last time. Let’s ask it again.','You had trouble with this one.','I remember which one made you spend something.','You made this choice worth keeping.','I tried it. I watched. I kept the useful part.','I’m getting better at this particular question.'),
 counterBait:L('You wanted me to catch it. I’ll come closer instead.','You keep leaving that opening on purpose.','I saw the invitation. I don’t have to accept it.','You set that little trap again.','I remember what you choose after you make me chase.','A baited hand is still holding a knife.'),
 repeated:L('Again. It’s still working.','You haven’t answered this one yet.','I can choose it twice. Watch.','Why would I stop while you’re still doing that?','You were waiting for me to change the question.','I’m not taking turns being clever.'),
 relentless:L('I can eat and keep watching.','I’m breathing. You’re still moving.','I counted the bag. Now I’ll make it lighter.','You thought that was a rest?','I only need a moment for myself.','I can see your hands from here.'),
 exhausted:L('My feet won’t keep up with my hands.','You can see it now, can’t you?','I’m trying. Keep looking.','There’s still a little left.','That was my knife. Mine.','I can’t make the room wait.'),
}
// @@ end

// @@ aqua-D002 — INTRO
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 994.
// NOTE: Line 2 now bridges from CORE: Sans’s scare tactic is what turned Aqua on Seth (the guide’s sanctioned bridge). The original theatre/crown callback is in the archive if you’d rather keep it.
INTRO=[
 ['You took your time, Seth.',1],['You heard the skeleton. If it takes a million tries, I want all of them.',0],['Geez. You left me almost nothing to play with.',1],['No. Don’t look behind you. The flower isn’t coming.',2],['So it’s just you and me now..~♡',0]
]
// @@ end

// @@ aqua-D003 — STORY
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 997.
STORY=[
 [['Ten.',1],['That’s your LOVE, right? Mine’s fourteen.',0],['That’s four more reasons not to just stand there.',2]],
 [['A monster taught me how the buttons work. It was SO proud of itself.',0],['I let it finish explaining. Then I tried them out.',1],['Patience. That’s what they call it, right?',2]],
 [['You watch the knife. I watch your thumb.',1],['It’s way easier to tell where you’re going that way.',0]],
 [['We both fell down here. We both saw how easy it was.',0],['They walk right up and introduce themselves. They tell you what hurts.',1],['And then they just... wait for you to decide.',2]],
 [['The flower showed me something once.',0],['He put a leaf in my hand, and I cut it. Next morning, it was whole again.',1],['Same leaf. Same little notch where my thumb had been.',2]],
 [['He told me I was imagining things.',1],['Then he told the same joke. Word for word.',0],['I laughed at the same part. He didn’t even notice.',2]],
 [['You keep calling this your turn.',1],['Who promised you that?',2]],
 [['I’ve been counting the places you stand.',0],['You’ve got a favorite corner. Everybody does.',1]],
 [['The king wants six souls. The flower wants all of them.',0],['Me? I only need the one right in front of me.',2]],
 [['Maybe killing you won’t be enough.',4],['Maybe I’ll still have to go find the flower afterward.',0],['But I’m not letting you get to him first.',2]],
 [['That color suits you.',1],['Let’s see how well you wear mine.',2]],
 [['Mary had a little lamb.',0],['My mother used to sing it when I wouldn’t sleep.',1],['I waited until she left the room. Then I got up.',2]],
 [['You’re eating again.',1],['Good. I brought enough for both of us.',0],['I mean that in the usual way.',2]],
 [['You wanna know what I’ll do first?',0],['Put everyone back. Every single one.',1],['And see how long it takes you to start again.',2]],
 [['Ooh. That scared you.',3],['I felt your hand stop.',1],['Do it again. I wanna see.',2]],
 [['You keep trying to hurt me while I’m talking.',4],['Honestly? I’d do the same thing.',2]],
 [['No, no. Don’t leave your hand on FIGHT.',1],['Someone might take it.',3]],
 [['The flower keeps coming back to the same patch of dirt.',0],['All that power, and he STILL has habits.',1],['I’ll be better at it than him.',2]],
 [['I know that look.',4],['You’re trying to make this mean something.',1],['You were smiling before you met me.',2]],
 [['I’m out of the sweet ones.',4],['You?',1]],
 [['It didn’t work.',4],['I tried the word. Nothing went back.',4],['Then I haven’t finished yet.',3]],
 [['Your hands are shaking too.',4],['There. That makes me feel better.',2]],
 [['If you win, don’t pretend you saved anyone.',4],['I would have put them back.',1],['For a while.',2]],
 [['Just one more time.',4],['That’s what he gets. One more time. As many as he wants.',3],['Give it to me.',5]]
]
// @@ end

// @@ aqua-D004 — REACTIONS
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 1023.
REACTIONS={
 read:[['You’re taking notes?',1],['Fine. I’ll change the question.',2]],
 bait:[['That little opening was on purpose.',1],['You really do think we’re alike.',2]],
 anchor:[['Hold still, then.',1],['Let’s see which one of us gets bored.',2]],
 steal:[['Don’t touch my menu.',4],['...Okay. That was kinda funny.',2]],
 mercy:[['For me?',1],['You should have tried that several rooms ago.',2]],
 miss:[['Too slow.',1]],hit:[['That one counted.',4]],
 falseSave:[['You believed it.',3],['You really believed I’d let you keep that.',2]]
}
// @@ end

// @@ aqua-D009 — confirm
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 292.
// NOTE: ACT/BIND quips and the theft line keep their timing; only the theft line is loosened.
confirm(direct=false){
  if(this.paused)return;
  if(this.menuLive&&!direct&&['menu','act','item','mercy','bind'].includes(this.state)){const index=this.liveOption();if(index<0)return;if(this.state==='menu')this.selected=index;else this.option=index;}
  if(this.state==='dialogue'){if(this.displayChars<this.text.length){this.displayChars=this.text.length;return;}if(this.pages.length){this.showPage();return;}const next=this.after;if(next==='menu')this.toMenu();else if(next==='enemy')this.startEnemy();else if(next==='wave')this.beginWave();else if(next==='apply-enemy')this.applyEnemy();else if(next==='won'){this.state='won';this.ending='won';this.brain.outcome('win',this);this.timer=0;this.emit('end');}else if(next==='dead'){this.state='dead';this.timer=0;this.emit('dead');}return;}
  if(this.state==='menu'){
   if(this.selected===0){this.brain.action('fight',this);if(this.completed>=16&&!this.stealCountered&&!this.stolen){this.stolen=true;this.menuLive=false;this.say('Thanks! My turn.',3);this.state='theft';this.timer=0;this.emit('deny');}else if(this.stolen){this.say('Looking for this?',2);this.startEnemy();}else this.startDuel();return;}
   this.state=['','act','item','mercy'][this.selected];this.option=0;this.emit('select');return;
  }
  if(this.state==='act'){
   const choice=this.option;if(choice!==2)this.brain.action(['read','bait','bind','steal'][choice],this);
   if(choice===2){this.state='bind';this.option=0;return;}
   if(choice===0){this.advantage=3;this.say('Fine. Watch closely.',1);this.actionReport='READ: your next throws lead her dodge.';}
   if(choice===1){this.bait=3;this.enemy.stamina=Math.max(.05,this.enemy.stamina-.5);this.enemyBuff.guard=0;this.actionReport='BAIT: she commits; her dodge weakens.';this.say('I saw that opening.',2);}
   if(choice===3){if(this.stolen||this.completed>=7){this.stolen=false;this.stealCountered=true;this.statuses={};this.enemy.bind=3;this.enemy.mode='purple';this.enemy.boundMode='purple';this.actionReport='You reclaim FIGHT. Her next ACT is cancelled.';this.say('Keep your hands to yourself.',4);}else{this.enemy.stamina=Math.max(.05,this.enemy.stamina-.3);this.actionReport='You interrupt her menu. She loses her rhythm.';}}
   this.startEnemy(choice===3?'interrupted':null);return;
  }
  if(this.state==='bind'){this.brain.action('bind',this);this.enemy.mode=['blue','green','purple','cyan'][this.option];this.enemy.boundMode=this.enemy.mode;this.enemy.bind=4;this.enemy.stamina=Math.max(.05,this.enemy.stamina-.18);this.actionReport=`AQUA: ${this.enemy.mode.toUpperCase()} SOUL. Four exchanges.`;this.say(['You first.','Try getting behind me.','Three lines? Really?','Careful. I know this one.'][this.option],2);this.startEnemy('bound');return;}
  if(this.state==='item'){const item=this.items.filter(x=>x.count)[this.option];if(!item){this.toMenu();return;}this.brain.action('item',this);const heal=Math.min(this.maxHP-this.hp,item.heal);this.hp+=heal;item.count--;delete this.statuses.bleed;this.actionReport=`${item.name}. +${heal} HP.`;this.emit('heal');this.startEnemy();return;}
  if(this.state==='mercy'){this.brain.action('mercy',this);this.message(REACTIONS.mercy);return;}
  if(['duel','defend','warning'].includes(this.state)){if(this.fakeSave){this.takeFakeSave();return;}if(this.split){this.cross();return;}if(this.mode==='cyan'&&this.state!=='duel'){this.orbitSign*=-1;this.emit('warp');return;}if(this.state==='duel'||this.mode==='yellow')this.shoot();return;}
  if(this.state==='saved'){this.takeFakeSave();return;}
  if(this.state==='dead'||this.state==='won'){this.reset();}
 }
// @@ end

