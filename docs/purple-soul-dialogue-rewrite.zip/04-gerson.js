// Gerson — What For?
// Drop-in dialogue rewrite for Purple Soul. Generated against the 9 Oct 2026 archive.
// Each block between "// @@ <id>" and "// @@ end" replaces the archive block of the same id.
// Only quoted text changed: code, indices, face/pose numbers, speaker tags, destinations,
// bank lengths, template expressions and control/label strings are byte-for-byte the originals.

// @@ gerson-D002 — INTRO
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 275.
INTRO=[g('Wa ha ha! There you are.',1),g('Left quite a mess back there, didn’t you? Not hard to follow.'),g('My little protégé wanted first crack at you. I told her she wasn’t ready.',2),g('Undyne didn’t like that one bit. She never does.'),g('Wanting a fight’s the easy part, kid. Knowing what you’re fighting is the hard part.'),g('Go on, then. Show this old turtle what you’ve got.',1)]
// @@ end

// @@ gerson-D003 — ORIGINAL_BEFORE
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 276.
ORIGINAL_BEFORE=[
 [g('Swinging like that? Wa ha ha! You’ll run out of breath before I do.',1)],
 [g('You don’t quit easy, do you? What’s your name, kid?'),s('Seth.'),g('Seth, eh? I’ll remember that one.'),f('Psst! Down here! Golly, that old fossil’s in the way of BOTH of us.'),f('You watch the hammer. I’ll keep that shield busy.'),f('I’ll wall off two sides with my vines. You block the other two!'),f('And watch my vines. When they start cracking, that side’s about to open up!')],
 [g('Purple, eh? Perseverance. Figures you’d be a stubborn one, Seth.',1),g('So tell me. What’s all that perseverance FOR?',3),g('You’ve come an awful long way. Ever stop and think about where it ends?'),f('Switching sides, Seth! RIGHT and DOWN are mine this time!')],
 [g('Huh. Your timing got better all of a sudden.'),g('That shield won’t stop a shell, though. Better get those feet moving.'),f('Don’t listen to the old geezer! Take the opening!')],
 [g('Wa ha ha! Look at that. Finally found your feet.',1),g('Now let’s see who’s really doin’ the thinking around here.')],
 [g('Those strings are yours, eh? Let’s put ’em to work.'),g('Could’ve used a little more kindness in that heart, Seth.',4),g('Perseverance got you this far. Kindness might’ve gotten you back out.'),s('WASD — move. ARROWS — turn the shield.')],
 [g('My girl Undyne hits harder than you do, y’know.',1),g('But she’d have gone chasing after that flower and let you stroll right past.'),g('Still got a few things to learn, that one.')],
 [g('Ever heard of the Delta Rune, kid?'),g('An angel who’s seen the surface comes down from above... and the Underground goes empty.'),g('...Wa ha ha! What’s that face for?',1),g('You think it’s you?'),g('Nah. Sorry, kid. It’s an old story. Me, I always thought the emblem just looked neat.'),g('Thing about stories is, folks rush past the important parts to get to the ending.',3)],
 [g('Back in my day, I could swing this thing from breakfast to bedtime.'),g('Don’t need that long anymore. Just a little while longer.',4)],
 [g('Still here, Seth?'),g('Shame. I’d have liked to see what that stubborn streak could do somewhere else.',3)],
 [g('...Whew.',4),g('Don’t get excited. I can still lift a hammer.'),g('They oughta be well clear by now.'),g('Wa ha ha. Thought I was just flapping my gums, kid? Every word bought them a few more steps.',1)],
 [g('You really want through that bad?'),g('All right, Seth. One last lesson.',2),g('Let’s see how well that heart takes a fall.')]
]
// @@ end

// @@ gerson-D004 — ORIGINAL_AFTER
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 290.
ORIGINAL_AFTER=[
 [s('The hammer catches most of your swing.\nSome of the force gets through anyway.')],
 [f('See? We make a great team! Keep it up!')],
 [g('You heard me, Seth. What for?'),f('Who cares?! We’re WINNING!')],
 [g('That little weed sure has a lot to say.'),f('He’s looking at YOU, dummy! Hit him again!')],
 [],
 [g('Two things at once. Keep up, kid.',1)],
 [g('So busy watching the shield, you forgot your feet.')],
 [g('Three lessons at once, and you’re still standing.',1),g('But how much of the first ones did you really hang onto?'),g('Let’s go over ’em again. Just you and me this time.')],
 [g('...Heh. Gettin’ a little old for this.',4)],
 [g('Thought you had me that time, eh?',1)],
 [s('His grip is shaking. His eye never leaves you.')]
]
// @@ end

// @@ gerson-D005 — EVICTION
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 303.
EVICTION=[g('There you are.'),f('Huh?'),g('Wa ha ha! Thought you could hide behind the kid, did you?',1),f('Seth! Hit him! NOW!'),g('You first.',2)]
// @@ end

// @@ gerson-D006 — FLEE
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 304.
FLEE=[f('Hey— that was a cheap shot!'),g('Come on back, then.',1),f('...You can handle the old geezer yourself. Right, Seth? Right?'),s('The flower ducks back beneath the stones.'),g('Now. Where were we?'),g('Let’s find out what YOU can do on your own.')]
// @@ end

// @@ gerson-D007 — ENDING
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 305.
// NOTE: The compact ENDING keeps Aqua’s exit line verbatim (user-authored). Only Gerson’s lines changed.
ENDING=[g('...Caught it.',4),g('You’re still watching the hammer, Seth.'),g('You oughta be watching—',2),{text:'Geez, Seth... you really are only slowing me down. But that was good EXP! I’ll see you around..~♡',speaker:'aqua',face:0},s('Aqua leaves ahead of you.'),s('GERSON WAS KILLED.\nYOU EARNED 0 EXP.')]
// @@ end

// @@ gerson-D008 — DEATH
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 321.
DEATH=[g('...Ah.',2),g('Two of you. Shoulda kept an eye on the passage.',3),g('Seth... still persevering, eh?',4),g('Don’t you let her answer that question for you. What for?',3),g('...Undyne. You stay with the others. Y’hear me?',4),g('Wa ha ha... they got away. That’s good enough for me.',1)]
// @@ end

// @@ gerson-D009 — AQUA
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 322.
// NOTE: Aqua’s first and last lines are kept verbatim (user-authored). The middle lines are rewritten.
AQUA=[{text:'Geez, Seth... you really are only slowing me down. But that was good EXP!',speaker:'aqua',face:0},{text:'You had his hammer. I had his back. See? We work great together.',speaker:'aqua',face:0},{text:'Oh, don’t give me that look. You were going to kill him anyway.',speaker:'aqua',face:0},{text:'You wear them down, I make it count. That’s teamwork, right?',speaker:'aqua',face:0},{text:'Try to keep up next time, okay? I really hate waiting.',speaker:'aqua',face:0},{text:'I’ll see you around..~♡',speaker:'aqua',face:0},s('Aqua leaves ahead of you.'),s('GERSON WAS KILLED.\nYOU EARNED 0 EXP.')]
// @@ end

// @@ gerson-D010 — SOLO_BEFORE
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 325.
SOLO_BEFORE=[
 [g('Recognize this stance, Seth?',1),g('Same hammer. Same shield. Only now there’s no flower minding the corners.'),g('You got through it once. Show me what actually stuck.')],
 [g('That flower told you where to look.'),g('Nice thing, having somebody watch your back.'),g('But you can’t borrow somebody else’s eyes forever.'),g('So where’s the next arrow coming from, kid?')],
 [g('Wa ha ha! Still waiting for him to pop up?',1),g('Four sides to mind, and only one shield to do it.'),g('Don’t swing that shield ’cause you’re scared. Swing it ’cause you saw what was coming.'),g('There’s a difference.')],
 [g('Enough standing still. Remember these strings?'),g('No vines to catch the shells this time.'),g('As a little urchin, Undyne took every hit head-on. Thought stepping aside meant losing.',1),g('Took a few bruises to teach her otherwise.')],
 [g('You’re quicker on your feet than when you walked in.'),g('That’s what worries me, Seth.',3),g('You can learn your way past anything... and never once ask if you should.'),g('One more. Make your own opening this time.')]
]
// @@ end

// @@ gerson-D011 — SOLO_AFTER
// Type: dialogue/data bank. Source: ` story.js `; owner ` modules["story.js"] `; script line 332.
SOLO_AFTER=[
 [g('There. Your shield. Your timing.'),g('Nobody else gets to take credit for that part.')],
 [g('You looked before you moved.'),g('Keep that habit when this is over. Might save more than your hide.',3)],
 [g('Heh. You managed just fine without those walls.',1),g('Standing on your own doesn’t mean you gotta push everybody away.')],
 [g('Found a way around. That counts too.'),g('Not everything in your way needs breaking, kid.')],
 [g('Well, well. You remembered.',4),g('Arrows, shells... you can tell ’em apart now.'),g('Let’s see if you keep your head when they come at you together again.',2)]
]
// @@ end

// @@ gerson-D016 — confirm
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 75.
confirm(){if(this.paused||this.state==='dead'&&(this.deathAge||0)<1.8)return;if(this.state==='dialogue'){if(this.displayChars<this.text.length){this.displayChars=this.text.length;return;}if(this.pages.length)this.showPage();else this.advance(this.next);return;}if(this.state==='dead'){this.retry();return;}if(this.state==='menu'){this.activate(['fight','act','item','mercy'][this.selected]);return;}if(this.state==='options'){const option=this.option;if(this.submenu==='item'){const item=this.items.filter(i=>i.count)[option];if(!item)return;item.count--;this.hp=Math.min(this.maxHP,this.hp+item.heal);this.emit('heal');this.preAttack([{text:`The warmth settles in your chest.\n${item.heal} HP restored.`,speaker:'seth',face:-1}]);}else{const pages=option===0?[{text:'GERSON\nOld war hero. His guard eats most of your damage.\nHe’s breathing harder now.',speaker:'seth',face:-1}]:option===1?[{text:'You ask what he’s waiting for.',speaker:'seth',face:-1},{text:'For you to get tired, or get wise. I’m not picky.',speaker:'gerson',face:1}]:[{text:'You tell him you’re not stopping.',speaker:'seth',face:-1},{text:'I believe you, Seth. That’s the trouble.',speaker:'gerson',face:3}];this.fatigue+=2;this.preAttack(pages);}return;}if(this.state==='strike'){const score=1-Math.abs(this.cursor-.5)*2;this.fatigue+=2+Math.round(score*5);this.strikeScore=score;this.pendingDamage=12*(6+Math.round(score*15));this.blockResolved=false;this.state='blocked';this.timer=0;this.emit('slash');return;}if(this.state==='landing'){this.state='clash';this.timer=0;this.enemyDamage(1,'last');this.emit('slash');return;}}
// @@ end

// @@ gerson-D018 — toMenu
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 81.
toMenu(){this.state='menu';this.mode='purple';this.bullets=[];this.effects=[];this.support=[];this.supportFX=[];this.vineWalls=[];this.angle=this.angleTarget=0;this.arena={x:214,y:264,w:340,h:176};this.selected=0;this.timer=0;this.text=this.turn>=LAST_COMBINED_TURN?'The hammer’s starting to drag.':'Gerson holds the passage.';}
// @@ end

// @@ gerson-D020 — retry
// Type: dialogue/trigger handler. Source: ` engine.js `; owner ` modules["engine.js"] `; script line 83.
retry(){if(this.state==='dead'&&(this.deathAge||0)<1.8)return;this.hp=this.maxHP;this.startAttack(this.checkpoint);this.say('Again, Seth? Heh. All right.',3);this.emit('retry');}
// @@ end

// @@ gerson-D021 — this.say
// Type: event. Source: ` engine.js `; owner ` raiseVineWalls `; script line 104.
this.say(`FLOWEY: ${sides.join(' + ').toUpperCase()} are MINE! You block the other two!`,3)
// @@ end

// @@ gerson-D022 — this.say
// Type: event. Source: ` engine.js `; owner ` damageVineWall `; script line 105.
// Trigger:  if w.hp<=3&&!w.warned 
this.say('FLOWEY: Ack! My vines are splitting! Get ready!',2.4)
// @@ end

// @@ gerson-D023 — this.say
// Type: event. Source: ` engine.js `; owner ` damageVineWall `; script line 105.
// Trigger:  if !w.hp 
this.say(`FLOWEY: Uh-oh! The ${w.side.toUpperCase()} wall’s BREAKING!`,2)
// @@ end

// @@ gerson-D024 — this.say
// Type: event. Source: ` engine.js `; owner ` vineWallStep `; script line 106.
// Trigger:  if w.breaking>=0&&!w.broken  →  if w.breaking<=0 
this.say(`FLOWEY: ${w.side.toUpperCase()} is OPEN! Your turn, pal!`,2.2)
// @@ end

// @@ gerson-D025 — this.say
// Type: event. Source: ` engine.js `; owner ` floweyStep `; script line 111.
// Trigger:  if this.time>=this.nextHelp  →  if this.mode!=='green' 
this.say(danger.length?'FLOWEY: Leave the green ones to ME!':'FLOWEY: Keep moving! I’ve got the old fossil!',2.3)
// @@ end

// @@ gerson-D026 — this.say
// Type: event. Source: ` engine.js `; owner ` pattern `; script line 114.
// Trigger:  if this.mode!=='green'&&t>=this.nextSpin 
this.say('Mind your footing, kid.',1.5)
// @@ end

// @@ supplementary — reactive lines from the archive's "Additional text" ledger
// These live outside the banks above. Find `old` at `where` and replace it with `new`.
const SUPPLEMENTARY_LINE_REWRITES=[
 {id:'gerson-T013',where:'engine.js / activate · text:\'Then we’re still doing this.\'',
  old:'Then we’re still doing this.',
  new:'Then I guess we’re still doin’ this.'},
 {id:'gerson-T014',where:'engine.js / update · text:this.strikeScore>.75?\'Good aim. Still got my guard.\':\'Heh. Felt that one.\'',
  old:'Good aim. Still got my guard.',
  new:'Good aim, kid. Still got my guard up, though.'},
 {id:'gerson-T015',where:'engine.js / update · text:this.strikeScore>.75?\'Good aim. Still got my guard.\':\'Heh. Felt that one.\'',
  old:'Heh. Felt that one.',
  new:'Oof! Wa ha... felt that one.'},
 {id:'gerson-T077',where:'entry / inline / ui · text(\'An old turtle is still waiting.\',384,298,1.8,\'#9daea3\',true)',
  old:'An old turtle is still waiting.',
  new:'The old turtle’s still waiting.'},
];
// @@ end
