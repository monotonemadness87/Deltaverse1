// Muffet — The Dark Nest
// Drop-in dialogue rewrite for Purple Soul. Generated against the 9 Oct 2026 archive.
// Each block between "// @@ <id>" and "// @@ end" replaces the archive block of the same id.
// Only quoted text changed: code, indices, face/pose numbers, speaker tags, destinations,
// bank lengths, template expressions and control/label strings are byte-for-byte the originals.

// @@ muffet-D003 — lines
// Type: dialogue/data bank. Source: ` src/engine.cjs `; owner ` finishFight `; script line 1009.
// Trigger:  if target==='muffet' 
lines=[S.n((this.isVisible()?'The lava light finds her. So does your notebook.':'Your notebook catches something moving in the dark.')+' '+damage+' damage.')]
// @@ end

// @@ muffet-D004 — lines
// Type: dialogue/data bank. Source: ` src/engine.cjs `; owner ` killCaptive `; script line 1039.
lines=[S.n((spam?'The NEO arm cracks. The stolen determination gutters out.\nSpamson turns to dust.':'Tenna reaches for his partner. Your notebook gets there first.\nThe little host turns to dust.')+'\n100 EXP. LV '+this.lv+'. Maximum HP +4.')]
// @@ end

// @@ muffet-D006 — lines
// Type: dialogue/data bank. Source: ` src/engine.cjs `; owner ` withdraw `; script line 1586.
lines=[{...S.p('…Enough.\nThis hunt has gotten far too expensive.','HURT'),ending:true},{...S.p('Keep your miserable little life, dearie.\nI’m keeping mine.','ANNOYED'),ending:true}]
// @@ end

// @@ muffet-D007 — INTRO
// Type: dialogue/data bank. Source: ` src/story.cjs `; owner ` "src/story.cjs" `; script line 2055.
INTRO=[
 n('The evacuation has barricaded every road but one.\nHotland goes quiet behind you.'),
 n('Spamson hangs in the silk. Still alive.\nA familiar blue ribbon twitches inside another cocoon.'),
 p('Ahuhuhu~ There you are, dearie.\nI was starting to think I’d have to send the girls to fetch you.'),
 p('One little human caught in my silk…\nAnd another walks right in on her own.\nOh, I do love completing a set~','CRUEL_GLEE'),
 p('You two will make such a lovely main course.\nAnd that plump little ant? Dessert, naturally~','HUNGRY'),
 n('Your soul turns purple.\nFollow a string. Up and down change lanes.\nCut the nest, find light, or free someone who can help.')
]
// @@ end

// @@ muffet-D008 — MILESTONES
// Type: dialogue/data bank. Source: ` src/story.cjs `; owner ` "src/story.cjs" `; script line 2063.
MILESTONES={
 5:[p('You’ve gotten so comfortable with the seating arrangement.\nLet’s freshen it up~','PLOTTING')],
 10:[p('Girls, bring them in closer.'),p('Ahuhuhu~ There you are.\nLet’s see how well you know your way around.','CRUEL_GLEE')],
 15:[p('Why should the table always stay the same way up?\nHold on to your little heart, dearie.','TEASING')],
 20:[p('Be a dear and make some room.')],
 25:[p('No more hopping from string to string.\nFollow them properly, like a good guest.','PLOTTING')],
 30:[p('You remember the way, don’t you?\nThe girls have made a few improvements~','TEASING')],
 35:[p('There’s that thread you keep choosing.\nI thought it looked a little lonely.','CURIOUS')],
 40:[p('My, my. Still moving?\nThen let’s make a little less room.','TEASING')],
 45:[p('So many strings, so little time.\nI’m sure you’ll find somewhere to stand~','FALSE_PITY')],
 50:[p('My, my… All this talking has made my throat so sore.'),p('A nice hot bowl of human stew should fix that right up.','HUNGRY'),p('Ahuhuhu…','CHUCKLE')],
 59:[p('You must be getting so tired, dearie.','FALSE_PITY'),p('All that struggling… and you’re still in my web.\nHow futile~','FALSE_PITY')],
 60:[p('That’s quite enough now.','SAVORING'),p('Ahuhuhu… The web is finished, dearie. Every last knot.','SAVORING'),p('Now sit tight, sweetie~','SAVORING')]
}
// @@ end

// @@ muffet-D009 — POOLS
// Type: dialogue/data bank. Source: ` src/story.cjs `; owner ` "src/story.cjs" `; script line 2077.
POOLS={
 hipBump:[['Time to rearrange the dinner table.','PLOTTING'],['Just a little nudge, dearie.\nDo keep hold of your thread.','TEASING'],['Ahuhuhu~ You looked far too settled.','CHUCKLE']],
 boxSpin:[['Perhaps the table needs a turn.','PLOTTING'],['Round and round we go, sweetie.\nHold on to something.','TEASING'],['These two hands hold the frame.\nThe other four will keep you company.','COY']],
 handSmash:[['A little bug on a little thread.','SAVORING'],['So much scurrying.\nYou’d fit so nicely in my palm.','CRUEL_GLEE'],['Hold still for just a moment, dearie.','FALSE_PITY']],
 spiders:[
 ['The girls have been practicing their steps.','COY'],['A little dance before dinner~','TEASING'],['Keep moving, sweetie. They do love a chase.','COY'],['That corner looks awfully crowded.','CURIOUS'],['Taking the same little path again, are we?','PLOTTING'],['My, such careful feet.\nSuch a tiny little room.','FALSE_PITY'],['That one hasn’t eaten today.\nTry not to upset her.','HUNGRY']
 ],
 pet:[['Oh, she’s been waiting all day for this~','CRUEL_GLEE'],['You didn’t think the little ones were the whole family, did you?','TEASING'],['She likes her meals lively.','SAVORING'],['Mind your head, dearie.','COY'],['Don’t make her ask for seconds.','HUNGRY'],['Such a bouncy appetite.\nIsn’t she charming?','CHUCKLE']],
 whiteTea:[['Careful, sweetie.\nThat cup is mine.','TEASING'],['A fresh pot.\nHave a little splash~','COY'],['Oh dear. Did I spill?','FALSE_PITY'],['That string was looking a little dry.','PLOTTING'],['Don’t stand under the spout.\nUnless you insist~','TEASING'],['White tea.\nA bit too sharp for you, I think.','SAVORING']],
 grab:[['Come closer, sweetie.\nI shouldn’t have to reach this far for one little bite.','HUNGRY'],['There. Almost close enough.','SAVORING'],['Hold that lovely little heart still.','HUSH'],['Let me help you off that string.','FALSE_PITY'],['Just one hand.\nThen all this running can stop.','COY'],['So small.\nI could carry you on one fingertip.','CURIOUS'],['The girls will mind the frame.\nI’ll mind you~','PLOTTING'],['Ahuhuhu… Open wide.','FERAL']],
 denyRescue:[['Careful with that one.\nI haven’t finished wondering what he is.','ANNOYED'],['Those knots took my girls all afternoon.','SUSPICIOUS'],['You’re rearranging my dinner table, dearie.','ANNOYED'],['One hand for the silk.\nOne hand for you.','TEASING'],['Still picking at the wrapping?','SUSPICIOUS'],['You could spend that time worrying about yourself~','FALSE_PITY']],
 greenTea:[['No little treats left?\nHere. I can afford to be generous.','FALSE_PITY'],['I’d hate for dinner to faint before it’s served~','COY'],['Green tea, dearie.\nWe’re not quite finished.','FALSE_PITY']]
}
// @@ end

// @@ muffet-D014 — this.finishAction
// Type: event. Source: ` src/engine.cjs `; owner ` chooseChoice `; script line 992.
// Trigger:  if this.menuTab==='MERCY' 
this.finishAction([S.n(id==='spare'?'You lower your notebook. The girls only move closer.':'You try the road behind you. Someone has knotted it shut.')])
// @@ end

// @@ muffet-D015 — finishFight
// Type: dialogue/trigger handler. Source: ` src/engine.cjs `; owner ` "src/engine.cjs" `; script line 1005.
finishFight(target,quality){
  if(this.state!=='aim')return;this.lastAction='fight:'+target;
  if(target==='spamson'||target==='killTenna'){this.killCaptive(target,quality);return;}
  if(target==='muffet'){
   const damage=this.damageBoss(this.fightDamage(quality)),lines=[S.n((this.isVisible()?'The lava light finds her. So does your notebook.':'Your notebook catches something moving in the dark.')+' '+damage+' damage.')];this.peakTargetThreat=Math.max(this.peakTargetThreat,.45);
   if(this.turn<=50&&this.completed%4===0)lines.push(S.p(this.isVisible()?'That lamp was covered for a reason.\nGirls, close it up.':'…How irritating.\nDon’t mistake a lucky reach for an invitation, dearie.','ANNOYED'));
   this.finishAction(lines);return;
  }
  const amount=Math.round(18+10*clamp(quality));this.cut(target,amount);this.finishAction([S.n('You cut '+amount+' strands from '+FIGHT_TARGETS.find(t=>t[0]===target)?.[1]+'.'),...this.cutDialogue]);
 }
// @@ end

// @@ muffet-D016 — cut
// Type: dialogue/trigger handler. Source: ` src/engine.cjs `; owner ` "src/engine.cjs" `; script line 1015.
cut(target,amount){
  this.cutDialogue=[];const max={light:180,aqua:132,arm:112,tenna:88,exit:90}[target];if(!max||this.exitSealed&&target==='exit')return;
  const before=this.progress[target];this.progress[target]=Math.min(max,before+amount);this.peakTargetThreat=Math.max(this.peakTargetThreat,.55);this.emit('cut',{target});
  if(target==='light'&&Math.floor(this.progress.light/60)>Math.floor(before/60)){
   this.eyeReveal=Math.min(1,this.progress.light/180);this.cutDialogue=[S.p('That lamp was covered for a reason.\nGirls, close it up.','ANNOYED')];
  }
  if(target==='aqua'&&this.progress.aqua>=132&&this.aqua.status==='captive'){
   this.aqua.status='active';this.aqua.joinedTurn=this.turn;this.aqua.action='ACT / JOIN';this.aqua.stamina=1;this.cutDialogue=[S.p('Oh, you’ve brought a friend to dinner.\nHow very thoughtful.','SUSPICIOUS'),S.a('Don’t celebrate.\nI want out. You’re useful for that.'),S.a('Sixty. That’s when she seals it. I counted.\nIf we’re still here by then, we’re dinner.')];this.emit('allyJoin');
  }
  if(target==='arm'&&this.progress.arm>=112&&!this.spamson.armFree){this.spamson.armFree=true;this.cutDialogue=[S.s(this.spamson.truth?'MY PARTNER IS ALIVE.\nAND THAT SPIDER HAS BEEN LAUGHING AT ME THE WHOLE TIME.\nGET HER IN MY SIGHTS.':'HEY! KEEP THE EDIBLE PARTS WRAPPED.\nWHO’S STILL MOVING OVER THERE?'),S.p('Leave that part wrapped, dearie.\nI’m quite sure it isn’t edible.','SUSPICIOUS')];}
  if(target==='tenna'&&this.progress.tenna>=88&&!this.tennaFree){
   this.tennaFree=true;this.checked.tenna=true;this.checked.spamson=true;
   this.cutDialogue=[S.t('BUDDY! I’M RIGHT HERE! LIVE AND IN PERSON!\nI COULD REALLY USE AN EXIT, FOLKS.')];
   if(!this.spamson.dead&&!this.spamson.truth){this.spamson.truth=true;this.cutDialogue.push(...this.truthDialogue());}
   this.cutDialogue.push(S.p('Not yet, sweetie.\nDessert comes AFTER the main course~','SAVORING'));
  }
  if(target==='exit'&&this.progress.exit>=90&&before<90)this.cutDialogue=[S.n('A small opening leads out along the upper silk.\nIt will take time to reach it.')];
 }
// @@ end

// @@ muffet-D017 — truthDialogue
// Type: dialogue/trigger handler. Source: ` src/engine.cjs `; owner ` "src/engine.cjs" `; script line 1033.
truthDialogue(){return [S.s('TENNA…?\nSHE HAD HIM THE WHOLE TIME?'),S.p('Oh, don’t spoil his lovely motivation, dearie.\nHe was so useful when he thought he’d lost everything.','FALSE_PITY'),S.s('YOU AND ME ARE NOT FRIENDS, KID.\nBUT I CAN SHOOT SOMETHING ELSE FIRST.')];}
// @@ end

// @@ muffet-D018 — killCaptive
// Type: dialogue/trigger handler. Source: ` src/engine.cjs `; owner ` "src/engine.cjs" `; script line 1034.
killCaptive(target,quality){
  const spam=target==='spamson',allowed=spam?this.spamson.armFree&&!this.spamson.dead:this.tennaFree&&!this.tennaDead;
  if(!allowed||quality<.08){this.finishAction([S.n('Your notebook misses its target.')]);return;}
  if(spam){this.spamson.dead=true;this.spamson.ammo=0;this.spamson.charge=0;}else{this.tennaDead=true;this.tennaDistraction=0;this.spamson.betrayed=true;}
  this.betrayals++;this.expGained+=100;this.lv++;this.seth.maxHP+=4;this.seth.hp=Math.min(this.seth.maxHP,this.seth.hp+4);this.emit('slash');this.effects.push({kind:'dust',x:682,y:spam?125:222,age:0});
  const lines=[S.n((spam?'The NEO arm cracks. The stolen determination gutters out.\nSpamson turns to dust.':'Tenna reaches for his partner. Your notebook gets there first.\nThe little host turns to dust.')+'\n100 EXP. LV '+this.lv+'. Maximum HP +4.')];
  if(!spam&&!this.spamson.dead)lines.push(S.s('YOU FREED HIM.\nYOU FREED HIM JUST TO—\nNO. YOU DON’T GET MY CANNON.'));
  if(spam&&this.tennaFree&&!this.tennaDead)lines.push(S.t('BUDDY…?\nWHY WOULD YOU DO THAT?'));
  if(this.aqua.status==='active')lines.push(S.a('You had a way out, and you chose that.\nI’m watching the exits now. And you.'));
  lines.push(S.p('Oh. How wasteful.\nYou’ve gone and ruined a perfectly good set.','ANNOYED'));this.finishAction(lines);
 }
// @@ end

// @@ muffet-D019 — act
// Type: dialogue/trigger handler. Source: ` src/engine.cjs `; owner ` "src/engine.cjs" `; script line 1045.
act(target,id){
  if(this.state!=='menu'||this.actDisabled(target,id))return;this.lastAction='act:'+target+':'+id;let lines=[];
  if(id==='check'){
   if(target in this.checked)this.checked[target]=true;
   if(target==='muffet')lines=[S.n('MUFFET — ATK 17 DEF 21\nA patient predator. She will abandon an expensive hunt.\nThe completed web closes on turn '+TURN_DEADLINE+'.')];
   if(target==='aqua')lines=[S.n(this.aqua.status==='captive'?'Aqua’s ribbon is caught under six layers of silk.\nShe waited too long. Cut the restraints.':this.aqua.status==='escaped'?'Her footsteps have gone quiet beyond the nest.':this.aquaDead?'Her light is gone.':'Aqua watches your notebook, then the nearest way out.')];
   if(target==='spamson'&&this.spamson.dead)lines=[S.n('Only dust remains. The cannon has gone quiet.')];
   else if(target==='spamson')lines=[S.n('Spamson is alive. Still not dust.\nThe NEO arm has its own restraints.'),S.p('Such a peculiar little morsel.\nHe still hasn’t turned to dust.','CURIOUS'),S.p('One of my girls had a little taste.\nShe said he was… strange.\nSo we’re keeping him. For now~','PLOTTING')];
   if(target==='tenna'&&this.tennaDead)lines=[S.n('Tenna is gone. No one announces the next act.')];
   else if(target==='tenna'){this.checked.tenna=true;lines=[S.t('ALIVE! YES!\nVERY MUCH ALIVE, FOLKS!'),S.n('You have proof. Tenna was here all along.'),S.p('Not yet, sweetie.\nDessert comes AFTER the main course~','SAVORING')];}
   if(target==='light')lines=[S.n('Silk smothers three lava lamps.\nEach cleared layer improves your reach.')];
   if(target==='exit')lines=[S.n(this.exitSealed?'Muffet has sealed the passage behind Aqua.':'A narrow route reaches the edge of the nest.\nThe anchor needs 90 strands cut.\nIt will not make Muffet release Seth.')];
  }else if(id==='cut'){
   const cutTarget=target==='spamson'?'arm':target;this.cut(cutTarget,24);lines=[S.n('You peel away a layer of silk. '+this.targetDetail(cutTarget)+'.'),...this.cutDialogue];
  }else if(id==='truth'){
   this.spamson.truth=true;lines=this.truthDialogue();
  }else if(id==='shot'){
   this.spamson.ammo--;this.spamson.shots++;this.spamson.charge=0;this.cannonFlash=1.5;this.peakTargetThreat=1;const hit=this.damageBoss(160*1.5**(this.spamson.shots-1),'spamson');
   lines=[S.s('HERE’S YOUR STRANGE LITTLE MOUTHFUL! ON THE HOUSE!'),S.n('The freed NEO arm fires through the light. '+hit+' damage.'),S.p('AH—!\nYou ungrateful little—!\nI was KEEPING you!','SHOCKED'),S.n(this.rebindAid('arm')),S.p('Girls. Wrap that dreadful thing up again.','ANNOYED')];this.emit('cannon');
  }else if(id==='charge'){
   this.spamson.charge++;lines=[S.s(this.spamson.charge>=2?(this.spamson.ammo===1?'ONE LAST SHOT.\nDON’T WASTE MY BATTERY.':'ANOTHER SHOT IS READY.\nGET HER IN MY SIGHTS.'):'HOLD ON. THIS ARM IS STILL MOSTLY WEB.\nONE MORE CHARGE.')];
  }else if(id==='distract'){
   this.tennaDistraction=2;lines=[S.t('LIVE FROM INSIDE A SPIDER’S DINNER PARTY!\nEYES ON ME, LADIES!'),S.n('The spiders turn toward the old host.\nMuffet’s outline becomes clearer.'),S.n(this.rebindAid('tenna'))];
  }else if(id==='talk'){
   lines=[S.a(this.turn>=43?'We’re running out of room.\nI’m counting her damage. And the exits.':'I pick my own openings.\nYou keep cutting. Keep moving.')];
  }else if(id==='opening'){
   this.exposure=Math.max(this.exposure,2);lines=[S.n('You signal the disturbance in the dark.'),S.a('I saw it.\nIf it’s worth the risk, I’ll take it.')];
  }else if(id==='listen'){
   this.exposure=2;lines=[S.n('A laugh travels through the silk.\nYou follow it to a white smile.\nHer position is exposed for two turns.'),S.p('Ahuhuhu~ Looking for me?','WHISPER')];
  }else if(id==='taunt'){
   this.taunt=2;lines=[S.n('You draw her eyes away from the other human.'),S.p('Oh, sweetie.\nI have more than enough hands for both of you.','TEASING')];
  }
  this.finishAction(lines);
 }
// @@ end

// @@ muffet-D022 — allyTurn
// Type: dialogue/trigger handler. Source: ` src/engine.cjs `; owner ` "src/engine.cjs" `; script line 1094.
allyTurn(){
  if(this.bossHP<=this.withdrawalHP&&this.turn>=TURN_DEADLINE){this.withdraw();return;}
  if(this.aqua.status!=='active'){this.prepareEnemy();return;}
  const missing=this.bossHP-this.withdrawalHP,late=this.turn>=43;
  const recentWaves=this.allyDamageHistory.slice(-4);
  const recentDamage=recentWaves.reduce((a,b)=>a+b,0)/Math.max(1,recentWaves.length);
  const expectedWaveDamage=Math.max(4,recentDamage,Math.max(0,...recentWaves)*.75)*(this.turn%10===0?1.6:this.turn%5===0?1.2:1);
  const captureRisk=clamp((1-this.aqua.hp/this.aqua.maxHP)*.3+(this.turn/TURN_DEADLINE)*.12+(this.lastFamily==='grab'?.16:0));
  const decision=this.allyAI.choose({turn:this.turn,status:this.aqua.status,aqua:this.aqua,muffet:{hp:this.bossHP,maxHP:this.bossMax,withdrawalHP:this.withdrawalHP,visible:this.isVisible(),exposure:this.exposure},expectedTeamDamagePerTurn:this.teamForecast(),immediateAllyDamage:this.allyFightDamage(),predictedCaptureRisk:captureRisk,sethCaptureRisk:1-this.seth.hp/this.seth.maxHP,betrayals:this.betrayals,recentDamagePerWave:recentDamage,expectedWaveDamage,fullAllyDamage:23*this.vulnerability(),exposurePrepareTurns:Math.ceil((60-this.progress.light)/32),exposureDamageGain:(14+6)*this.vulnerability(),
   canExpose:this.progress.light<60,exposureTarget:'light',canCutSupport:late&&this.progress.exit<90&&!this.exitSealed,supportTarget:'exit',supportValue:late?.1:0,canDistract:this.seth.hp<15&&!this.betrayals,canGuard:true,
   escape:{reachable:this.progress.exit>=90&&!this.exitSealed,route:'upper-silk',travelTurns:1,prepareTurns:Math.ceil((90-this.progress.exit)/42),canPrepare:!this.exitSealed,preparationTarget:'exit'}});
  this.aqua.decision=decision;this.aqua.action=decision.action.toUpperCase();this.allyOutcome={action:decision.action,ownDamage:0,muffetDamage:0,objectiveGain:0};let line='';
  if(decision.action==='fight'){
   const damage=this.damageBoss(this.allyFightDamage(),'aqua');this.allyOutcome.muffetDamage=damage;this.aqua.stamina=Math.max(.1,this.aqua.stamina-.11);this.aqua.action='FIGHT / '+damage;line=missing<=this.teamForecast()*1.2?'One more opening. Don’t waste it.':'We can still make her leave. Move.';
  }else if(decision.action==='expose'){
   this.cut('light',32);this.allyOutcome.objectiveGain=32/60;this.aqua.action='ACT / EXPOSE';line='That lamp. Keep her eyes on you.';
  }else if(decision.action==='cutSupport'||decision.action==='prepareEscape'){
   if(decision.action==='prepareEscape')this.aqua.retreating=true;
   this.cut('exit',42);this.allyOutcome.objectiveGain=42/90;this.aqua.action='ACT / EXIT';line='I’m finding another way out. Keep her busy.';
  }else if(decision.action==='recover'){
   this.aqua.stamina=Math.min(1,this.aqua.stamina+.55);this.aqua.action='ACT / RECOVER';line='Give me a second.';
  }else if(decision.action==='guard'){
   this.aqua.guard=1;this.aqua.action='ACT / GUARD';line='That hand. Watch it.';
  }else if(decision.action==='item'){
   const item=this.aqua.items.splice(decision.itemIndex,1)[0];if(item)this.aqua.hp=Math.min(this.aqua.maxHP,this.aqua.hp+item.heal);this.aqua.action='ITEM / '+(item?.name||'');this.emit('heal');line='My supplies. My choice.';
  }else if(decision.action==='distract'){
   this.taunt=0;this.aquaDraw=1;this.aqua.guard=.5;this.aqua.action='ACT / DISTRACT';line='I’ll take her eyes. Move.';
  }else if(decision.action==='flee'){
   this.aqua.retreating=true;
   this.aqua.status='fleeing';this.aqua.action='FLEE';this.aquaPath=null;line='You’ve taken too long. I’m leaving.';
  }
  this.allyMessage=line;this.allyMessageAge=4.5;this.emit('allyAction',{action:this.aqua.action});
  // Joining and departures get a full line; other decisions remain readable party barks.
  if(decision.action==='flee')this.say([S.a(line)],()=>this.prepareEnemy());else this.prepareEnemy();
 }
// @@ end

// @@ muffet-D025 — withdraw
// Type: dialogue/trigger handler. Source: ` src/engine.cjs `; owner ` "src/engine.cjs" `; script line 1585.
withdraw(){
  this.won=true;const lines=[{...S.p('…Enough.\nThis hunt has gotten far too expensive.','HURT'),ending:true},{...S.p('Keep your miserable little life, dearie.\nI’m keeping mine.','ANNOYED'),ending:true}];
  if(['active','fleeing'].includes(this.aqua.status))lines.push({...S.p('Ahuhuhu~ Go on, then.\nTake your new friend with you.\nShe’s ever so good at waiting.','WHISPER'),ending:true});
  this.say(lines,()=>{this.state='won';this.timer=0;this.message=this.endingText();if(this.aqua.status==='captive'){this.aqua.status='rescued';this.progress.aqua=132;}this.persist('win');this.emit('win');});
 }
// @@ end

// @@ muffet-D031 — bark
// Type: dialogue/trigger handler. Source: ` src/story.cjs `; owner ` bark `; script line 2090.
function bark(g,family){
 if(g.turn>50&&g.turn<59)return [];
 if(MILESTONES[g.turn])return MILESTONES[g.turn];
 const pool=POOLS[family]||POOLS.spiders,i=(g.barkCounts[family]||0)%pool.length;g.barkCounts[family]=(g.barkCounts[family]||0)+1;
 return g.turn===17?[p(...pool[i]),p('What’s the matter, dearie?\nWould you like another hand?')]:[p(...pool[i])];
}
// @@ end

// @@ supplementary — reactive lines from the archive's "Additional text" ledger
// These live outside the banks above. Find `old` at `where` and replace it with `new`.
const SUPPLEMENTARY_LINE_REWRITES=[
 {id:'muffet-T196',where:'src/engine.cjs / projectileFired · spiders:\'The girls have found your favourite thread.\'',
  old:'The girls have found your favourite thread.',
  new:'The girls have learned your favorite thread.'},
 {id:'muffet-T199',where:'src/engine.cjs / projectileFired · grab:\'Keep still, and she can serve you by hand.\'',
  old:'Keep still, and she can serve you by hand.',
  new:'Hold still, and she’ll serve you by hand.'},
];
// @@ end
